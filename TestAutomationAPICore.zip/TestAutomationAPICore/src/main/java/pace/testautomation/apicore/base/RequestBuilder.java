package pace.testautomation.apicore.base;

import java.io.File;
import java.io.InputStream;
import java.util.Collection;
import java.util.Map;

import io.restassured.authentication.OAuthSignature;
import io.restassured.http.ContentType;
import io.restassured.http.Cookie;
import io.restassured.http.Cookies;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.mapper.ObjectMapper;
import io.restassured.mapper.ObjectMapperType;
import io.restassured.specification.RequestSpecification;

interface RequestBuilder {

	public RequestSpecification getRequest();

	/**
	 * Add cookie to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withCookie("cookie-name", cookieValue);
	 * }
	 * </pre>
	 * 
	 * @param cookieName  : Cookie name
	 * @param cookieValue : Cookie value
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withCookie(String cookieName, Object cookieValue, Object... additionalValues) {
		this.getRequest().cookie(cookieName, cookieValue, additionalValues);
		return (ApiSettings) this;
	}

	/**
	 * Add cookie to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withCookie(cookie);
	 * }
	 * </pre>
	 * 
	 * @param cookie : Rest assured http cookie
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withCookie(Cookie cookie) {
		this.getRequest().cookie(cookie);
		return (ApiSettings) this;
	}

	/**
	 * Add cookie to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withCookie("odoc-csrf");
	 * }
	 * </pre>
	 * 
	 * @param cookieName : Name of the cookie without value
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withCookie(String cookieName) {
		this.getRequest().cookie(cookieName);
		return (ApiSettings) this;
	}

	/**
	 * Add cookies to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withCookies(prevResponse.cookies());
	 * }
	 * </pre>
	 * 
	 * @param cookies : Rest assured http cookies
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withCookies(Cookies cookies) {
		this.getRequest().cookies(cookies);
		return (ApiSettings) this;
	}

	/**
	 * Add cookies to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withCookies(cookiesMap);
	 * }
	 * </pre>
	 * 
	 * @param cookies : Map containing cookie name against cookie value
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withCookies(Map<String, ?> cookies) {
		this.getRequest().cookies(cookies);
		return (ApiSettings) this;
	}

	/**
	 * Add cookies to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withCookies("first-cookie-name", firstCookieValue, "second-cookie-name", secondCookieValue);
	 * }
	 * </pre>
	 * 
	 * @param firstCookieName      : Name of the first cookie
	 * @param firstCookieValue     : Value of the first cookie
	 * @param cookieNameValuePairs : This represents the optional 'n' number of
	 *                             cookie name value pairs
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withCookies(String firstCookieName, Object firstCookieValue, Object... cookieNameValuePairs) {
		this.getRequest().cookies(firstCookieName, firstCookieValue, cookieNameValuePairs);
		return (ApiSettings) this;
	}

	/**
	 * Add content type header to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withContentType(ContentType.JSON);
	 * }
	 * </pre>
	 * 
	 * @param contentType : Content type value
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withContentType(ContentType contentType) {
		this.getRequest().contentType(contentType);
		return (ApiSettings) this;
	}

	/**
	 * Add content type header to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withContentType("application/json");
	 * }
	 * </pre>
	 * 
	 * @param contentType : Content type value
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withContentType(String contentType) {
		this.getRequest().contentType(contentType);
		return (ApiSettings) this;
	}

	/**
	 * Instruct the request specification not to include content-type
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withoutContentType();
	 * }
	 * </pre>
	 * 
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withoutContentType() {
		this.getRequest().noContentType();
		return (ApiSettings) this;
	}

	/**
	 * Add request body to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withBody(jsonPayload.toString());
	 * }
	 * </pre>
	 * 
	 * @param body : Request body value
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withBody(String body) {
		this.getRequest().body(body);
		return (ApiSettings) this;
	}

	/**
	 * Add request body to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withBody(jsonPayload);
	 * }
	 * </pre>
	 * 
	 * @param body : Request body value
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withBody(Object body) {
		this.getRequest().body(body);
		return (ApiSettings) this;
	}

	/**
	 * Add request body to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withBody(requestBodyFile);
	 * }
	 * </pre>
	 * 
	 * @param body : Request body value
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withBody(File body) {
		this.getRequest().body(body);
		return (ApiSettings) this;
	}

	/**
	 * Add request body to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * byte[] someBytes = ..
	 * apiSettings.withBody(someBytes);
	 * }
	 * </pre>
	 * 
	 * @param body : Request body value
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withBody(byte[] body) {
		this.getRequest().body(body);
		return (ApiSettings) this;
	}

	/**
	 * Add request body to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * InputStream someInputStream = ..
	 * apiSettings.withBody(someInputStream);
	 * }
	 * </pre>
	 * 
	 * @param body : Request body value
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withBody(InputStream body) {
		this.getRequest().body(body);
		return (ApiSettings) this;
	}

	/**
	 * Add request body to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Message message = new Message();
	 * message.setMessage("My beautiful message");
	 * apiSettings.withBody(message, new MyObjectMapper());
	 * }
	 * </pre>
	 * 
	 * @param body         : Request body object
	 * @param objectMapper : The object mapper
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withBody(Object body, ObjectMapper objectMapper) {
		this.getRequest().body(body, objectMapper);
		return (ApiSettings) this;
	}

	/**
	 * Add request body to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Message message = new Message();
	 * message.setMessage("My beautiful message");
	 * apiSettings.withBody(message, ObjectMapperType.GSON);
	 * }
	 * </pre>
	 * 
	 * @param body             : Request body object
	 * @param objectMapperType : The object mapper type to be used
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withBody(Object body, ObjectMapperType objectMapperType) {
		this.getRequest().body(body, objectMapperType);
		return (ApiSettings) this;
	}

	/**
	 * Add maximum redirects count to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withRedirects(3);
	 * }
	 * </pre>
	 * 
	 * @param noOfRedirects : Maximum number of times the request can redirect to.
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withRedirects(int noOfRedirects) {
		this.getRequest().redirects().max(noOfRedirects).and().redirects().follow(true);
		return (ApiSettings) this;
	}

	/**
	 * Stop the request from redirecting
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withoutRedirects();
	 * }
	 * </pre>
	 * 
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withoutRedirects() {
		this.getRequest().redirects().follow(false);
		return (ApiSettings) this;
	}

	/**
	 * Add parameters to the request specifications
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withParams("token", tokenValue, "username", userNameValue, "password", passwordValue);
	 * }
	 * </pre>
	 * 
	 * @param firstParamName          : Name of the first parameter
	 * @param firstParamValue         : Value of the first parameter
	 * @param parameterNameValuePairs : This represents the optional 'n' number of
	 *                                parameter name value pairs
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withParams(String firstParamName, Object firstParamValue, Object... parameterNameValuePairs) {
		this.getRequest().params(firstParamName, firstParamValue, parameterNameValuePairs);
		return (ApiSettings) this;
	}

	/**
	 * Add parameters to the request specifications
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Map<String, String> parameters = new HashMap<String, String>();
	 * parameters.put("username", "John");
	 * parameters.put("token", "1234");
	 * apiSettings.withParams(parameters);
	 * }
	 * </pre>
	 * 
	 * @param parametersMap : The Map containing parameter name as key and parameter
	 *                      value as map-value
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withParams(Map<String, ?> parametersMap) {
		this.getRequest().params(parametersMap);
		return (ApiSettings) this;
	}

	/**
	 * Add parameter to the request specifications
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withParam("name", value1, value2);
	 * }
	 * </pre>
	 * 
	 * @param paramName   : Name of the parameter
	 * @param paramValues : Parameter values, one to many if you want to specify
	 *                    multiple values for the same parameter
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withParam(String paramName, Object... paramValues) {
		this.getRequest().param(paramName, paramValues);
		return (ApiSettings) this;
	}

	/**
	 * Add parameter to the request specifications
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withParam("cars", asList("Volvo", "Saab"));
	 * }
	 * </pre>
	 * 
	 * @param paramName  : Name of the parameter
	 * @param paramValue : Collection of parameter values
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withParam(String paramName, Collection<?> paramValue) {
		this.getRequest().param(paramName, paramValue);
		return (ApiSettings) this;
	}

	/**
	 * Add query parameters to the request specifications
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withQueryParams("pageNumber", 1, "pageSize", 10, "enabled", true);
	 * }
	 * </pre>
	 * 
	 * @param firstParamName          : Name of the first parameter
	 * @param firstParamValue         : Value of the first parameter
	 * @param parameterNameValuePairs : This represents the optional 'n' number of
	 *                                parameter name value pairs
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withQueryParams(String firstParamName, Object firstParamValue,
			Object... parameterNameValuePairs) {
		this.getRequest().queryParams(firstParamName, firstParamValue, parameterNameValuePairs);
		return (ApiSettings) this;
	}

	/**
	 * Add query parameters to the request specifications
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Map<String, String> parameters = new HashMap<String, String>();
	 * parameters.put("pageNumber", "1");
	 * parameters.put("pageSize", "10");
	 * apiSettings.withQueryParams(parameters);
	 * }
	 * </pre>
	 * 
	 * @param parametersMap : The Map containing parameter name as key and parameter
	 *                      value as map-value
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withQueryParams(Map<String, ?> parametersMap) {
		this.getRequest().queryParams(parametersMap);
		return (ApiSettings) this;
	}

	/**
	 * Add query parameter to the request specifications
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withQueryParam("name", value1, value2);
	 * }
	 * </pre>
	 * 
	 * @param paramName   : Name of the parameter
	 * @param paramValues : Parameter values, one to many if you want to specify
	 *                    multiple values for the same parameter
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withQueryParam(String paramName, Object... paramValues) {
		this.getRequest().queryParam(paramName, paramValues);
		return (ApiSettings) this;
	}

	/**
	 * Add query parameter to the request specifications
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withQueryParam("cars", asList("Volvo", "Saab"));
	 * }
	 * </pre>
	 * 
	 * @param paramName  : Name of the parameter
	 * @param paramValue : Collection of parameter values
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withQueryParam(String paramName, Collection<?> paramValue) {
		this.getRequest().queryParam(paramName, paramValue);
		return (ApiSettings) this;
	}

	/**
	 * Add form parameters to the request specifications
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withFormParams("title", "New Title", "description", "Some description", "pages", 100);
	 * }
	 * </pre>
	 * 
	 * @param firstParamName          : Name of the first parameter
	 * @param firstParamValue         : Value of the first parameter
	 * @param parameterNameValuePairs : This represents the optional 'n' number of
	 *                                parameter name value pairs
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withFormParams(String firstParamName, Object firstParamValue,
			Object... parameterNameValuePairs) {
		this.getRequest().formParams(firstParamName, firstParamValue, parameterNameValuePairs);
		return (ApiSettings) this;
	}

	/**
	 * Add form parameters to the request specifications
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Map<String, String> parameters = new HashMap<String, String>();
	 * parameters.put("title", "New Title");
	 * parameters.put("description", "Some description");
	 * apiSettings.withFormParams(parameters);
	 * }
	 * </pre>
	 * 
	 * @param parametersMap : The Map containing parameter name as key and parameter
	 *                      value as map-value
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withFormParams(Map<String, ?> parametersMap) {
		this.getRequest().formParams(parametersMap);
		return (ApiSettings) this;
	}

	/**
	 * Add form parameter to the request specifications
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withFormParam("name", value1, value2);
	 * }
	 * </pre>
	 * 
	 * @param paramName   : Name of the parameter
	 * @param paramValues : Parameter values, one to many if you want to specify
	 *                    multiple values for the same parameter
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withFormParam(String paramName, Object... paramValues) {
		this.getRequest().formParam(paramName, paramValues);
		return (ApiSettings) this;
	}

	/**
	 * Add form parameter to the request specifications
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withFormParam("cars", asList("Volvo", "Saab"));
	 * }
	 * </pre>
	 * 
	 * @param paramName  : Name of the parameter
	 * @param paramValue : Collection of parameter values
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withFormParam(String paramName, Collection<?> paramValue) {
		this.getRequest().formParam(paramName, paramValue);
		return (ApiSettings) this;
	}

	/**
	 * Add accept header to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withAccept(ContentType.JSON);
	 * }
	 * </pre>
	 * 
	 * @param contentType : Content type value
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withAccept(ContentType contentType) {
		this.getRequest().accept(contentType);
		return (ApiSettings) this;
	}

	/**
	 * Add accept header to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withAccept("application/json");
	 * }
	 * </pre>
	 * 
	 * @param contentType : Content type value
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withAccept(String contentType) {
		this.getRequest().accept(contentType);
		return (ApiSettings) this;
	}

	/**
	 * Add a header to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withHeader("header-name", headerValue1);
	 * }
	 * </pre>
	 * 
	 * @param headerName             : Name of the header
	 * @param headerValue            : Value of the header
	 * @param additionalHeaderValues : Additional header values. This will actually
	 *                               create two headers with the same name but with
	 *                               different values.
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withHeader(String headerName, Object headerValue, Object... additionalHeaderValues) {
		this.getRequest().header(headerName, headerValue, additionalHeaderValues);
		return (ApiSettings) this;
	}

	/**
	 * Add a header to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Header someHeader = new Header("some_name", "some_value");
	 * apiSettings.withHeader(someHeader);
	 * }
	 * </pre>
	 * 
	 * @param header : Rest assured http header
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withHeader(Header header) {
		this.getRequest().header(header);
		return (ApiSettings) this;
	}

	/**
	 * Add multiple headers to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Map<String, String> headers = new HashMap<String, String>();
	 * parameters.put("headerName1", "headerValue1");
	 * parameters.put("headerName2", "headerValue2");
	 * apiSettings.withHeaders(headers);
	 * }
	 * </pre>
	 * 
	 * @param headers : The Map containing header names as key and header values as
	 *                map-value
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withHeaders(Map<String, ?> headers) {
		this.getRequest().headers(headers);
		return (ApiSettings) this;
	}

	/**
	 * Add multiple headers to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withHeaders("headerName1", "headerValue1", "headerName2", "headerValue2");
	 * }
	 * </pre>
	 * 
	 * @param firstHeaderName      : Name of the first header
	 * @param firstHeaderValue     : Value of the first header
	 * @param headerNameValuePairs : This represents the optional 'n' number of
	 *                             header name value pairs
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withHeaders(String firstHeaderName, Object firstHeaderValue, Object... headerNameValuePairs) {
		this.getRequest().headers(firstHeaderName, firstHeaderValue, headerNameValuePairs);
		return (ApiSettings) this;
	}

	/**
	 * Add multiple headers to the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Header first = new Header("headerName1", "headerValue1");
	 * Header second = new Header("headerName2", "headerValue2");
	 * Headers headers = new Headers(first, second);
	 * apiSettings.withHeaders(headers);
	 * }
	 * </pre>
	 * 
	 * @param headers : Rest assured http headers
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withHeaders(Headers headers) {
		this.getRequest().headers(headers);
		return (ApiSettings) this;
	}

	/**
	 * Add basic authentication to the request's authentication specifications
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withBasicAuthentication("user-name", password);
	 * }
	 * </pre>
	 * 
	 * @param userName : User name
	 * @param password : Password
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withBasicAuthentication(String userName, String password) {
		this.getRequest().auth().basic(userName, password);
		return (ApiSettings) this;
	}
	
	/**
	 * Add basic authentication to the request's authentication specifications
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withPreemptiveBasicAuthentication("user-name", password);
	 * }
	 * </pre>
	 * 
	 * @param userName : User name
	 * @param password : Password
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.2.0
	 * @since 2023-07-15
	 */
	default ApiSettings withPreemptiveBasicAuthentication(String userName, String password) {
		this.getRequest().auth().preemptive().basic(userName, password);
		return (ApiSettings) this;
	}

	/**
	 * Add OAuth authentication to the request's authentication specifications
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withOAuth("consumer-key", consumerSecret, accessToken, secretToken);
	 * }
	 * </pre>
	 * 
	 * @param consumerKey    : Consumer key
	 * @param consumerSecret : Consumer secret
	 * @param accessToken    : Access token
	 * @param secretToken    : Secret token
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withOAuth(String consumerKey, String consumerSecret, String accessToken, String secretToken) {
		this.getRequest().auth().oauth(consumerKey, consumerSecret, accessToken, secretToken);
		return (ApiSettings) this;
	}

	/**
	 * Add OAuth authentication to the request's authentication specifications
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withOAuth("consumer-key", consumerSecret, accessToken, secretToken, OAuthSignature.HEADER);
	 * }
	 * </pre>
	 * 
	 * @param consumerKey    : Consumer key
	 * @param consumerSecret : Consumer secret
	 * @param accessToken    : Access token
	 * @param secretToken    : Secret token
	 * @param signature      : OAuth signature to be used
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withOAuth(String consumerKey, String consumerSecret, String accessToken, String secretToken,
			OAuthSignature signature) {
		this.getRequest().auth().oauth(consumerKey, consumerSecret, accessToken, secretToken, signature);
		return (ApiSettings) this;
	}

	/**
	 * Add OAuth2 authentication to the request's authentication specifications
	 * Token name will be taken as 'Bearer'
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withOAuth2(tokenValue);
	 * }
	 * </pre>
	 * 
	 * @param accessToken : Access token already generated for the targeted request
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withOAuth2(String accessToken) {
		this.getRequest().auth().oauth2(accessToken);
		return (ApiSettings) this;
	}

	/**
	 * Add OAuth2 authentication to the request's authentication specifications
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withOAuth2("JWT", tokenValue);
	 * }
	 * </pre>
	 * 
	 * @param tokenName   : The name of the access token
	 * @param accessToken : Access token already generated for the targeted request
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withOAuth2(String tokenName, String accessToken) {
		this.getRequest().header("Authorization", tokenName + " " + accessToken);
		return (ApiSettings) this;
	}

	/**
	 * Add OAuth2 authentication to the request's authentication specifications
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.withOAuth2(tokenValue, OAuthSignature.HEADER);
	 * }
	 * </pre>
	 * 
	 * @param accessToken : Access token already generated for the targeted request
	 * @param signature   : The OAuth signature to be used
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings withOAuth2(String accessToken, OAuthSignature signature) {
		this.getRequest().auth().oauth2(accessToken, signature);
		return (ApiSettings) this;
	}
}
