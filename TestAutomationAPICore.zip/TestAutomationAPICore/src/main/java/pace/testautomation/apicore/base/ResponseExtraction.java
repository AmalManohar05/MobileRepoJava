package pace.testautomation.apicore.base;

import java.util.Map;

import org.json.JSONObject;

import io.restassured.http.Cookies;
import io.restassured.http.Headers;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.response.ValidatableResponseLogSpec;

interface ResponseExtraction {

	public Response getResponse();

	/**
	 * Get the valdatable response
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.getValidatableResponse();
	 * }
	 * </pre>
	 * 
	 * @return Rest assured validatable response
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ValidatableResponse getValidatableResponse() {
		return this.getResponse().then();
	}

	/**
	 * Get the response logger
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.getResponseLogger();
	 * }
	 * </pre>
	 * 
	 * @return Rest assured response logger
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ValidatableResponseLogSpec<ValidatableResponse, Response> getResponseLogger() {
		return this.getResponse().then().log();
	}

	/**
	 * Get the response json path
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.getResponseJsonPath();
	 * }
	 * </pre>
	 * 
	 * @return Rest assured response json path
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default JsonPath getResponseJsonPath() {
		return this.getResponse().jsonPath();
	}

	/**
	 * Get the response json
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.getResponseJson();
	 * }
	 * </pre>
	 * 
	 * @return Rest assured response json
	 * 
	 * @author PACE Team
	 * @version 1.2.0
	 * @since 2024-07-15
	 */
	default JSONObject getResponseJson() {
		return new JSONObject(this.getResponseBody());
	}

	/**
	 * Get the response xml path
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.getResponseXmlPath();
	 * }
	 * </pre>
	 * 
	 * @return Rest assured response xml path
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default XmlPath getResponseXmlPath() {
		return this.getResponse().xmlPath();
	}

	/**
	 * Get the response body
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.getResponseBody();
	 * }
	 * </pre>
	 * 
	 * @return Rest assured response body as string
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default String getResponseBody() {
		return this.getResponse().getBody().asString();
	}

	/**
	 * Get the response status code
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.getResponseStatusCode();
	 * }
	 * </pre>
	 * 
	 * @return Rest assured response status code as integer
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default int getResponseStatusCode() {
		return this.getResponse().getStatusCode();
	}

	/**
	 * Get the response status line
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.getResponseStatusLine();
	 * }
	 * </pre>
	 * 
	 * @return Rest assured response status line as string
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default String getResponseStatusLine() {
		return this.getResponse().getStatusLine();
	}

	/**
	 * Get the response headers
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.getResponseHeaders();
	 * }
	 * </pre>
	 * 
	 * @return Rest assured response headers as collection of headers
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default Headers getResponseHeaders() {
		return this.getResponse().getHeaders();
	}

	/**
	 * Get the response header value
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.getResponseHeaderValue();
	 * }
	 * </pre>
	 * 
	 * @return Rest assured response header value as string
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default String getResponseHeaderValue(String headerName) {
		return this.getResponse().getHeader(headerName);
	}

	/**
	 * Get the response cookies
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.getResponseCookies();
	 * }
	 * </pre>
	 * 
	 * @return Rest assured response cookies as key value pairs
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default Map<String, String> getResponseCookies() {
		return this.getResponse().cookies();
	}

	/**
	 * Get the response cookies in detail
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.getResponseCookiesInDetail();
	 * }
	 * </pre>
	 * 
	 * @return Rest assured response cookies
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default Cookies getResponseCookiesInDetail() {
		return this.getResponse().getDetailedCookies();
	}

	/**
	 * Get the response cookie value
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.getResponseCookieValue();
	 * }
	 * </pre>
	 * 
	 * @return Rest assured response cookie value as string
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default String getResponseCookieValue(String cookieName) {
		return this.getResponse().getCookie(cookieName);
	}
}
