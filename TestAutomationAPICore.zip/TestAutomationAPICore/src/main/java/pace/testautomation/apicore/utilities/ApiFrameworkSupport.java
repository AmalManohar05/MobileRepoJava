package pace.testautomation.apicore.utilities;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

public class ApiFrameworkSupport {

	/**
	 * Switch to turn off framework's expiry date check
	 * Set to 'true' to disable the check.
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	private final static Boolean disableExpiryCheck = false;
	
	/**
	 * Check the expiry date of the framework. Will raise warning pop ups before 1 week of expiry date.
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void FrameworkExpiryDateCheck()
	{
		if(disableExpiryCheck) {
			return;
		}
		LocalDate currentDate = LocalDate.now();
        LocalDate specificDate = LocalDate.of(2024, 12, 31);     
        if (currentDate.isAfter(specificDate)) {
        	try {
	            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        // Show an error dialog that cannot be closed
	        final JOptionPane pane = new JOptionPane("\n"+"PITS Test Automation Framework's validity expired on " + specificDate.format(DateTimeFormatter.ofPattern("dd/MMM/yyyy")) + "\n"+"Please contact pace@pitsolutions.com to get the latest version"+"\n"+"© 2023 PITS . All rights reserved."+"\n Thank you for respecting our intellectual property rights.",
	        		JOptionPane.ERROR_MESSAGE, 
	        		JOptionPane.DEFAULT_OPTION, null, new Object[]{}, null);
	        final JDialog dialog = pane.createDialog("Error : PITS Test Automation Framework expired");
	        dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
	        dialog.setModal(true);
	        dialog.setVisible(true);
            throw new RuntimeException("\n"+"PITS Test Automation Framework's validity expired on " + specificDate.format(DateTimeFormatter.ofPattern("dd/MMM/yyyy")) + "\n"+"Please contact pace@pitsolutions.com to get the latest version"+"\n"+"© 2023 PITS . All rights reserved.");
        } 
        else if (currentDate.isAfter(specificDate.minusWeeks(1))) {
        	try {
	            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        // Show an warning dialog
	        final JOptionPane pane = new JOptionPane("\n"+"PITS Test Automation Framework's validity will expire on " + specificDate.format(DateTimeFormatter.ofPattern("dd/MMM/yyyy")) + "\n"+"Please contact pace@pitsolutions.com to get the latest version"+"\n"+"© 2023 PITS . All rights reserved."+"\n Thank you for respecting our intellectual property rights.",
	        		JOptionPane.WARNING_MESSAGE, 
	        		JOptionPane.DEFAULT_OPTION, null, new Object[]{}, null);
	        final JDialog dialog = pane.createDialog("Warning : PITS Test Automation Framework will expire soon");
	        dialog.setModal(true);
	        dialog.setVisible(true);
         } 
	}
	
	/**
	 * Check the expiry date of the framework.
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void FrameworkExpiryDateCheckWithoutWarning()
	{
		if(disableExpiryCheck) {
			return;
		}
		LocalDate currentDate = LocalDate.now();
        LocalDate specificDate = LocalDate.of(2024, 12, 31);     
        if (currentDate.isAfter(specificDate)) {
        	try {
	            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        // Show an error dialog that cannot be closed
	        final JOptionPane pane = new JOptionPane("\n"+"PITS Test Automation Framework's validity expired on " + specificDate.format(DateTimeFormatter.ofPattern("dd/MMM/yyyy")) + "\n"+"Please contact pace@pitsolutions.com to get the latest version"+"\n"+"© 2023 PITS . All rights reserved."+"\n Thank you for respecting our intellectual property rights.",
	        		JOptionPane.ERROR_MESSAGE, 
	        		JOptionPane.DEFAULT_OPTION, null, new Object[]{}, null);
	        final JDialog dialog = pane.createDialog("Error : PITS Test Automation Framework expired");
	        dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
	        dialog.setModal(true);
	        dialog.setVisible(true);
            throw new RuntimeException("\n"+"PITS Test Automation Framework's validity expired on " + specificDate.format(DateTimeFormatter.ofPattern("dd/MMM/yyyy")) + "\n"+"Please contact pace@pitsolutions.com to get the latest version"+"\n"+"© 2023 PITS . All rights reserved.");
        }         
	}
}
