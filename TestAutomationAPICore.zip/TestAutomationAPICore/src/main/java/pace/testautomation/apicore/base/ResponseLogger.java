package pace.testautomation.apicore.base;

import io.restassured.response.Response;
import pace.testautomation.apicore.utilities.ExtentReportHelpers;

interface ResponseLogger {

	public Response getResponse();

	/**
	 * Log the response details
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.logResponseDetails();
	 * }
	 * </pre>
	 * 
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings logResponseDetails() {
		ExtentReportHelpers.log("\n STATUS CODE : " + this.getResponse().statusCode());
		ExtentReportHelpers.log("\n STATUS LINE : " + this.getResponse().statusLine());
		ExtentReportHelpers.log("\n RESPONSE HEADERS ↓");
		this.getResponse().getHeaders()
				.forEach(header -> ExtentReportHelpers.log("\n " + header.getName() + " : " + header.getValue()));
		ExtentReportHelpers.log("\n RESPONSE BODY ↓");
		ExtentReportHelpers.log(this.getResponse().getBody().asPrettyString());
		this.getResponse().then().log().everything();
		return (ApiSettings) this;
	}

	/**
	 * Log the response details if the status code is 4xx or 5xx
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.logResponseDetailsOnError();
	 * }
	 * </pre>
	 * 
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings logResponseDetailsOnError() {
		if (this.getResponse().statusCode() >= 400) {
			ExtentReportHelpers.log("\n STATUS CODE : " + this.getResponse().statusCode());
			ExtentReportHelpers.log("\n STATUS LINE : " + this.getResponse().statusLine());
			ExtentReportHelpers.log("\n RESPONSE HEADERS ↓");
			this.getResponse().getHeaders()
					.forEach(header -> ExtentReportHelpers.log("\n " + header.getName() + " : " + header.getValue()));
			ExtentReportHelpers.log("\n RESPONSE BODY ↓");
			ExtentReportHelpers.log(this.getResponse().getBody().asPrettyString());
		}
		this.getResponse().then().log().ifError();
		return (ApiSettings) this;
	}

	/**
	 * Log the response details if the status code is same as that given
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.logResponseDetailsOnStatusCode(201);
	 * }
	 * </pre>
	 * 
	 * @param statusCode : Required status code
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings logResponseDetailsOnStatusCode(int statusCode) {
		if (this.getResponse().statusCode() == statusCode) {
			ExtentReportHelpers.log("\n STATUS CODE : " + this.getResponse().statusCode());
			ExtentReportHelpers.log("\n STATUS LINE : " + this.getResponse().statusLine());
			ExtentReportHelpers.log("\n RESPONSE HEADERS ↓");
			this.getResponse().getHeaders()
					.forEach(header -> ExtentReportHelpers.log("\n " + header.getName() + " : " + header.getValue()));
			ExtentReportHelpers.log("\n RESPONSE BODY ↓");
			ExtentReportHelpers.log(this.getResponse().getBody().asPrettyString());
		}
		this.getResponse().then().log().ifStatusCodeIsEqualTo(statusCode);
		return (ApiSettings) this;
	}

	/**
	 * Log the response body as pretty string or normal string
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.logResponseBody(true);
	 * }
	 * </pre>
	 * 
	 * @param asPretty : Boolean value deciding whether the body is logged as pretty
	 *                 string or normal string
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings logResponseBody(Boolean asPretty) {
		ExtentReportHelpers.log("\n RESPONSE BODY ↓");
		if (asPretty)
			ExtentReportHelpers.log(this.getResponse().getBody().asPrettyString());
		else
			ExtentReportHelpers.log(this.getResponse().getBody().asString());
		this.getResponse().then().log().body(asPretty);
		return (ApiSettings) this;
	}


	/**
	 * Log the response status
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.logResponseStatus();
	 * }
	 * </pre>
	 * 
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.2.1
	 * @since 2024-07-30
	 */
	default ApiSettings logResponseStatus() {
		ExtentReportHelpers.log("\n RESPONSE STATUS : " + this.getResponse().statusLine());
		this.getResponse().then().log().status();
		return (ApiSettings) this;
	}
	
	/**
	 * Log the response headers
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.logResponseHeaders();
	 * }
	 * </pre>
	 * 
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings logResponseHeaders() {
		ExtentReportHelpers.log("\n RESPONSE HEADERS ↓");
		this.getResponse().getHeaders()
				.forEach(header -> ExtentReportHelpers.log("\n " + header.getName() + " : " + header.getValue()));
		this.getResponse().then().log().headers();
		return (ApiSettings) this;
	}

	/**
	 * Log the response cookies
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.logResponseCookies();
	 * }
	 * </pre>
	 * 
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings logResponseCookies() {
		ExtentReportHelpers.log("\n RESPONSE COOKIES ↓");
		this.getResponse().getCookies().forEach((name, value) -> ExtentReportHelpers.log("\n " + name + " : " + value));
		this.getResponse().then().log().cookies();
		return (ApiSettings) this;
	}

	/**
	 * Log the response cookies in detail
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.logResponseCookiesInDetail();
	 * }
	 * </pre>
	 * 
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings logResponseCookiesInDetail() {
		ExtentReportHelpers.log("\n RESPONSE COOKIES ↓");
		this.getResponse().getDetailedCookies()
				.forEach(cookie -> ExtentReportHelpers
						.log("\n name : " + cookie.getName() + " , " + "value : " + cookie.getValue() + " , "
								+ "domain : " + cookie.getDomain() + " , " + "path : " + cookie.getPath()));
		this.getResponse().then().log().cookies();
		return (ApiSettings) this;
	}
}
