package pace.testautomation.apicore.base;

interface GherkinSyntax {

	/**
	 * An optional method that can be used during the beginning of request building.
	 * This will return the same ApiSettings instance calling it without performing
	 * any action.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.given().request().withBody(requestBodyFile);
	 * }
	 * </pre>
	 * 
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings given() {
		return (ApiSettings)this;
	}

	/**
	 * An optional method that can be used before executing the request. This will
	 * return the same ApiSettings instance calling it without performing any
	 * action.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.when().executeRequest(Method.GET).then().getResponse();
	 * }
	 * </pre>
	 * 
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings when() {
		return (ApiSettings)this;
	}

	/**
	 * An optional method that can be used after executing the request. This will
	 * return the same ApiSettings instance calling it without performing any
	 * action.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.executeRequest(Method.GET).then().logResponseDetails();
	 * }
	 * </pre>
	 * 
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings then() {
		return (ApiSettings)this;
	}

	/**
	 * An optional method that can be used between similar methods. This will return
	 * the same ApiSettings instance calling it without performing any action.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.validate().responeShouldHaveStatusCode(200).and().responeShouldHaveStatusLine("Http OK");
	 * }
	 * </pre>
	 * 
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings and() {
		return (ApiSettings)this;
	}

	/**
	 * An optional method that can be used before calling response assertion
	 * methods. This will return the same ApiSettings instance calling it without
	 * performing any action.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.validate().responeShouldHaveStatusCode(200);
	 * }
	 * </pre>
	 * 
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings validate() {
		return (ApiSettings)this;
	}

	/**
	 * An optional method that can be used before calling request building methods.
	 * This will return the same ApiSettings instance calling it without performing
	 * any action.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.request().withBody(requestBodyFile);
	 * }
	 * </pre>
	 * 
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings request() {
		return (ApiSettings)this;
	}
}
