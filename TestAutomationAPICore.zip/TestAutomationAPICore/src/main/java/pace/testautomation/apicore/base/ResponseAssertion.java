package pace.testautomation.apicore.base;

import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.emptyString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.nullValue;

import org.hamcrest.Matcher;

import io.restassured.response.Response;
import pace.testautomation.apicore.utilities.ExtentReportHelpers;

interface ResponseAssertion {

	public Response getResponse();

	/**
	 * Asserting that the response should have the given status code. The method
	 * acts as a soft assertion if 'continueOnFailure' is set to true.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.responseShouldHaveStatusCode(200, true); {continue test execution even if assertion fails}
	 * 
	 * apiSettings.responseShouldHaveStatusCode(200, false); {stop test execution if assertion fails}
	 * }
	 * </pre>
	 * 
	 * @param statusCode        : Expected status code
	 * @param continueOnFailure : Boolean value determining whether or not to
	 *                          continue test execution if this assertion fails
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings responseShouldHaveStatusCode(int statusCode, boolean continueOnFailure) {
		if (!continueOnFailure)
			this.getResponse().then().statusCode(statusCode);
		else {
			try {
				this.getResponse().then().statusCode(statusCode);
			} catch (AssertionError e) {
				ExtentReportHelpers.logTestAtVerify(e);
			}
		}
		return (ApiSettings) this;
	}
	
	/**
	 * Asserting that the response should have the given status code.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.responseShouldHaveStatusCode(200);
	 * }
	 * </pre>
	 * 
	 * @param statusCode        : Expected status code
	 * 
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.2.0
	 * @since 2023-07-15
	 */
	default ApiSettings responseShouldHaveStatusCode(int statusCode) {
		if (this.getResponse().getStatusCode() != statusCode)
			throw new AssertionError("The expected status code was <"+ statusCode + "> but actual status code is <"+ this.getResponse().getStatusCode() +">");		
		return (ApiSettings) this;
	}

	/**
	 * Asserting that the response should have the status code meeting given
	 * condition. The method acts as a soft assertion if 'continueOnFailure' is set
	 * to true.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.responseShouldHaveStatusCode(greaterThan(200), true); {continue test execution even if assertion fails}
	 * 
	 * apiSettings.responseShouldHaveStatusCode(greaterThan(200), false); {stop test execution if assertion fails}
	 * }
	 * </pre>
	 * 
	 * @param condition         : Expected condition
	 * @param continueOnFailure : Boolean value determining whether or not to
	 *                          continue test execution if this assertion fails
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings responseShouldHaveStatusCode(Matcher<? super Integer> condition, boolean continueOnFailure) {
		if (!continueOnFailure)
			this.getResponse().then().statusCode(condition);
		else {
			try {
				this.getResponse().then().statusCode(condition);
			} catch (AssertionError e) {
				ExtentReportHelpers.logTestAtVerify(e);
			}
		}
		return (ApiSettings) this;
	}

	/**
	 * Asserting that the response should have the given status line. The method
	 * acts as a soft assertion if 'continueOnFailure' is set to true.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.responseShouldHaveStatusLine("Http OK", true); {continue test execution even if assertion fails}
	 * 
	 * apiSettings.responseShouldHaveStatusLine("Http OK", false); {stop test execution if assertion fails}
	 * }
	 * </pre>
	 * 
	 * @param statusLine        : Expected status line
	 * @param continueOnFailure : Boolean value determining whether or not to
	 *                          continue test execution if this assertion fails
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings responseShouldHaveStatusLine(String statusLine, boolean continueOnFailure) {
		if (!continueOnFailure)
			this.getResponse().then().statusLine(statusLine);
		else {
			try {
				this.getResponse().then().statusLine(statusLine);
			} catch (AssertionError e) {
				ExtentReportHelpers.logTestAtVerify(e);
			}
		}
		return (ApiSettings) this;
	}

	/**
	 * Asserting that the response should have the status line meeting given
	 * condition. The method acts as a soft assertion if 'continueOnFailure' is set
	 * to true.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.responseShouldHaveStatusCode(containsString("OK"), true); {continue test execution even if assertion fails}
	 * 
	 * apiSettings.responseShouldHaveStatusCode(containsString("OK"), false); {stop test execution if assertion fails}
	 * }
	 * </pre>
	 * 
	 * @param condition         : Expected condition
	 * @param continueOnFailure : Boolean value determining whether or not to
	 *                          continue test execution if this assertion fails
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings responseShouldHaveStatusLine(Matcher<? super String> condition, boolean continueOnFailure) {
		if (!continueOnFailure)
			this.getResponse().then().statusLine(condition);
		else {
			try {
				this.getResponse().then().statusLine(condition);
			} catch (AssertionError e) {
				ExtentReportHelpers.logTestAtVerify(e);
			}
		}
		return (ApiSettings) this;
	}

	/**
	 * Asserting that the response body should have the given value at the given
	 * path. The method acts as a soft assertion if 'continueOnFailure' is set to
	 * true.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.responseBodyShouldHaveValue("data.name", "givenName", true); {continue test execution even if assertion fails}
	 * 
	 * apiSettings.responseBodyShouldHaveValue("data.name", "givenName", false); {stop test execution if assertion fails}
	 * }
	 * </pre>
	 * 
	 * @param bodyPath          : Response body's path to specific value
	 * @param value             : Expected value to be present at the path
	 * @param continueOnFailure : Boolean value determining whether or not to
	 *                          continue test execution if this assertion fails
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings responseBodyShouldHaveValue(String bodyPath, Object value, boolean continueOnFailure) {
		if (!continueOnFailure)
			this.getResponse().then().body(bodyPath, equalTo(value));
		else {
			try {
				this.getResponse().then().body(bodyPath, equalTo(value));
			} catch (AssertionError e) {
				ExtentReportHelpers.logTestAtVerify(e);
			}
		}
		return (ApiSettings) this;
	}

	/**
	 * Asserting that the response body should have a value meeting the given
	 * condition at the given path. The method acts as a soft assertion if
	 * 'continueOnFailure' is set to true.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.responseBodyShouldHaveValue("data.name", containsString("Name"), true); {continue test execution even if assertion fails}
	 * 
	 * apiSettings.responseBodyShouldHaveValue("data.name", containsString("Name"), false); {stop test execution if assertion fails}
	 * }
	 * </pre>
	 * 
	 * @param bodyPath          : Response body's path to specific value
	 * @param condition         : Expected condition
	 * @param continueOnFailure : Boolean value determining whether or not to
	 *                          continue test execution if this assertion fails
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings responseBodyShouldHaveValue(String bodyPath, Matcher<?> condition, boolean continueOnFailure) {
		if (!continueOnFailure)
			this.getResponse().then().body(bodyPath, condition);
		else {
			try {
				this.getResponse().then().body(bodyPath, condition);
			} catch (AssertionError e) {
				ExtentReportHelpers.logTestAtVerify(e);
			}
		}
		return (ApiSettings) this;
	}

	/**
	 * Asserting that the response body should not contain the given string value.
	 * The method acts as a soft assertion if 'continueOnFailure' is set to true.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.responseBodyShouldNotContain("secret password", true); {continue test execution even if assertion fails}
	 * 
	 * apiSettings.responseBodyShouldNotContain("secret password", false); {stop test execution if assertion fails}
	 * }
	 * </pre>
	 * 
	 * @param value             : Value expected not to be present in response body
	 * @param continueOnFailure : Boolean value determining whether or not to
	 *                          continue test execution if this assertion fails
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings responseBodyShouldNotContain(String value, boolean continueOnFailure) {
		if (!continueOnFailure)
			this.getResponse().then().body(not(containsString(value)));
		else {
			try {
				this.getResponse().then().body(not(containsString(value)));
			} catch (AssertionError e) {
				ExtentReportHelpers.logTestAtVerify(e);
			}
		}
		return (ApiSettings) this;
	}

	/**
	 * Asserting that the response body should have not null value at the given
	 * path. The method acts as a soft assertion if 'continueOnFailure' is set to
	 * true.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.responseBodyShouldHaveNotNullValue("data.name", true); {continue test execution even if assertion fails}
	 * 
	 * apiSettings.responseBodyShouldHaveNotNullValue("data.name", false); {stop test execution if assertion fails}
	 * }
	 * </pre>
	 * 
	 * @param bodyPath          : Response body's path to specific value
	 * @param continueOnFailure : Boolean value determining whether or not to
	 *                          continue test execution if this assertion fails
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings responseBodyShouldHaveNotNullValue(String bodyPath, boolean continueOnFailure) {
		if (!continueOnFailure)
			this.getResponse().then().body(bodyPath, not(nullValue()));
		else {
			try {
				this.getResponse().then().body(bodyPath, not(nullValue()));
			} catch (AssertionError e) {
				ExtentReportHelpers.logTestAtVerify(e);
			}
		}
		return (ApiSettings) this;
	}

	/**
	 * Asserting that the response body should have null value at the given path.
	 * The method acts as a soft assertion if 'continueOnFailure' is set to true.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.responseBodyShouldHaveNullValue("data.name", true); {continue test execution even if assertion fails}
	 * 
	 * apiSettings.responseBodyShouldHaveNullValue("data.name", false); {stop test execution if assertion fails}
	 * }
	 * </pre>
	 * 
	 * @param bodyPath          : Response body's path to specific value
	 * @param continueOnFailure : Boolean value determining whether or not to
	 *                          continue test execution if this assertion fails
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings responseBodyShouldHaveNullValue(String bodyPath, boolean continueOnFailure) {
		if (!continueOnFailure)
			this.getResponse().then().body(bodyPath, nullValue());
		else {
			try {
				this.getResponse().then().body(bodyPath, nullValue());
			} catch (AssertionError e) {
				ExtentReportHelpers.logTestAtVerify(e);
			}
		}
		return (ApiSettings) this;
	}

	/**
	 * Asserting that the response body should be an empty string. The method acts
	 * as a soft assertion if 'continueOnFailure' is set to true.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.responseBodyShouldBeEmpty(true); {continue test execution even if assertion fails}
	 * 
	 * apiSettings.responseBodyShouldBeEmpty(false); {stop test execution if assertion fails}
	 * }
	 * </pre>
	 * 
	 * @param continueOnFailure : Boolean value determining whether or not to
	 *                          continue test execution if this assertion fails
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings responseBodyShouldBeEmpty(boolean continueOnFailure) {
		if (!continueOnFailure)
			this.getResponse().then().body(emptyString());
		else {
			try {
				this.getResponse().then().body(emptyString());
			} catch (AssertionError e) {
				ExtentReportHelpers.logTestAtVerify(e);
			}
		}
		return (ApiSettings) this;
	}

	/**
	 * Asserting that the response body should not be an empty string. The method
	 * acts as a soft assertion if 'continueOnFailure' is set to true.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.responseBodyShouldNotBeEmpty(true); {continue test execution even if assertion fails}
	 * 
	 * apiSettings.responseBodyShouldNotBeEmpty(false); {stop test execution if assertion fails}
	 * }
	 * </pre>
	 * 
	 * @param continueOnFailure : Boolean value determining whether or not to
	 *                          continue test execution if this assertion fails
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings responseBodyShouldNotBeEmpty(boolean continueOnFailure) {
		if (!continueOnFailure)
			this.getResponse().then().body(not(emptyString()));
		else {
			try {
				this.getResponse().then().body(not(emptyString()));
			} catch (AssertionError e) {
				ExtentReportHelpers.logTestAtVerify(e);
			}
		}
		return (ApiSettings) this;
	}

	/**
	 * Asserting that the response body should contain the given values at the given
	 * path. The method acts as a soft assertion if 'continueOnFailure' is set to
	 * true.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.responseBodyShouldContainValues(true, "data.keywords", "test" , "automation"); {continue test execution even if assertion fails}
	 * 
	 * apiSettings.responseBodyShouldContainValues(false, "data.keywords", "test" , "automation"); {stop test execution if assertion fails}
	 * }
	 * </pre>
	 * 
	 * @param continueOnFailure : Boolean value determining whether or not to
	 *                          continue test execution if this assertion fails
	 * @param bodyPath          : Response body's path to specific value
	 * @param values            : The values to be present at the given path
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings responseBodyShouldContainValues(boolean continueOnFailure, String bodyPath, Object... values) {
		if (!continueOnFailure)
			this.getResponse().then().body(bodyPath, hasItems(values));
		else {
			try {
				this.getResponse().then().body(bodyPath, hasItems(values));
			} catch (AssertionError e) {
				ExtentReportHelpers.logTestAtVerify(e);
			}
		}
		return (ApiSettings) this;
	}

	/**
	 * Asserting that the response body should contain all the given values at the
	 * given path. The method acts as a soft assertion if 'continueOnFailure' is set
	 * to true.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.responseBodyShouldContainEveryValues(true, "data.keywords", "test" , "automation"); {continue test execution even if assertion fails}
	 * 
	 * apiSettings.responseBodyShouldContainEveryValues(false, "data.keywords", "test" , "automation"); {stop test execution if assertion fails}
	 * }
	 * </pre>
	 * 
	 * @param continueOnFailure : Boolean value determining whether or not to
	 *                          continue test execution if this assertion fails
	 * @param bodyPath          : Response body's path to specific value
	 * @param values            : The values to be present at the given path
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	default ApiSettings responseBodyShouldContainEveryValues(boolean continueOnFailure, String bodyPath,
			Object... values) {
		if (!continueOnFailure)
			this.getResponse().then().body(bodyPath, contains(values));
		else {
			try {
				this.getResponse().then().body(bodyPath, contains(values));
			} catch (AssertionError e) {
				ExtentReportHelpers.logTestAtVerify(e);
			}
		}
		return (ApiSettings) this;
	}
}
