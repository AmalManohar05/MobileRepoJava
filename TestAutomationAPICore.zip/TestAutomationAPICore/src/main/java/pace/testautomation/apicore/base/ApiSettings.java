package pace.testautomation.apicore.base;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import pace.testautomation.apicore.utilities.ApiFrameworkSupport;

public class ApiSettings
		implements RequestBuilder, ResponseExtraction, ResponseLogger, ResponseAssertion, GherkinSyntax {

	/**
	 * Constructor for ApiSettings
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public ApiSettings() {
		ApiFrameworkSupport.FrameworkExpiryDateCheck();
		this.request = RestAssured.given();
	}

	/**
	 * Constructor for ApiSettings
	 * 
	 * @param baseUrl : The base path for the request end-point
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public ApiSettings(String baseUrl) {
		ApiFrameworkSupport.FrameworkExpiryDateCheck();
		this.baseUrl = baseUrl;
		this.request = RestAssured.given();
	}

	/**
	 * Base url
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	private String baseUrl = "";

	/**
	 * Request specification instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	private RequestSpecification request;

	/**
	 * Response instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	private Response response = null;

	/**
	 * Get the response
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.getResponse();
	 * }
	 * </pre>
	 * 
	 * @return Rest assured response
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	@Override
	public Response getResponse() {
		return this.response;
	}

	/**
	 * Get the request
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.getRequest();
	 * }
	 * </pre>
	 * 
	 * @return Rest assured request
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	@Override
	public RequestSpecification getRequest() {
		return this.request;
	}

	/**
	 * Reset the request specification
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.resetRequest();
	 * }
	 * </pre>
	 * 
	 * @return ApiSettings instance calling this method
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public ApiSettings resetRequest() {
		this.request = RestAssured.given();
		this.response = null;
		return this;
	}

	/**
	 * Execute the request
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.executeRequest(Method.GET, "/web/index.php/api/v2/pim/employees");
	 * }
	 * </pre>
	 * 
	 * @param methodType  : Request method type such as GET, POST, PUT, DELETE ..
	 * @param resourceUrl : Resource part of the request url
	 * @param pathParams  : Path parameters to replace in the request url *
	 * @return The response
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public ApiSettings executeRequest(Method methodType, String resourceUrl, Object... pathParams) {
		switch (methodType) {
		case GET: {
			this.response = this.getRequest().get(this.baseUrl + resourceUrl, pathParams);
			break;
		}
		case POST: {
			this.response = this.getRequest().post(this.baseUrl + resourceUrl, pathParams);
			break;
		}
		case PUT: {
			this.response = this.getRequest().put(this.baseUrl + resourceUrl, pathParams);
			break;
		}
		case PATCH: {
			this.response = this.getRequest().patch(this.baseUrl + resourceUrl, pathParams);
			break;
		}
		case DELETE: {
			this.response = this.getRequest().delete(this.baseUrl + resourceUrl, pathParams);
			break;
		}
		case HEAD: {
			this.response = this.getRequest().head(this.baseUrl + resourceUrl, pathParams);
			break;
		}
		case OPTIONS: {
			this.response = this.getRequest().options(this.baseUrl + resourceUrl, pathParams);
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + methodType);
		}
		return this;
	}

	/**
	 * Execute the request
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * apiSettings.executeRequest(Method.GET);
	 * }
	 * </pre>
	 * 
	 * @param methodType : Request method type such as GET, POST, PUT, DELETE ..
	 * @return The response
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public ApiSettings executeRequest(Method methodType) {
		switch (methodType) {
		case GET: {
			this.response = this.getRequest().get();
			break;
		}
		case POST: {
			this.response = this.getRequest().post();
			break;
		}
		case PUT: {
			this.response = this.getRequest().put();
			break;
		}
		case PATCH: {
			this.response = this.getRequest().patch();
			break;
		}
		case DELETE: {
			this.response = this.getRequest().delete();
			break;
		}
		case HEAD: {
			this.response = this.getRequest().head();
			break;
		}
		case OPTIONS: {
			this.response = this.getRequest().options();
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + methodType);
		}
		return this;
	}
}