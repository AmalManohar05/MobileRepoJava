package pace.testautomation.uicore.base;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.Platform;

public class BrowserOptions {

	/**
	 * Adding additional capabilities
	 * 
	 * @example BrowserOptions.AdditionalCapabilities(String hub, String
	 *          browserName)
	 * @param hub
	 * @param browserName
	 * @return additional capabilities of browser as hashmap
	 * 
	 * @author Pace Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static Map<Object, Object> additionalCapabilities(String hub, String browserName) {
		Map<Object, Object> browserOptions = new HashMap<Object, Object>();
		if (hub.equals("grid")) {
			browserOptions.put("browserName", browserName);
			browserOptions.put("platformName", Platform.XP);
		}
		return browserOptions;
	}
}