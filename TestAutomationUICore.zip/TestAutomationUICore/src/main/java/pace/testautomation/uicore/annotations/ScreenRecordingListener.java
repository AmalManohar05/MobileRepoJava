package pace.testautomation.uicore.annotations;

import org.testng.ITestListener;
import org.testng.ITestResult;

import pace.testautomation.uicore.utilities.MonteScreenRecorder;
import pace.testautomation.uicore.utilities.UiFrameworkSupport;

public class ScreenRecordingListener implements ITestListener {
	
	static {
		UiFrameworkSupport.FrameworkExpiryDateCheckWithoutWarning();
	}

	private static boolean recordingEnabled = false;

	/**
	 * Override method to be executed before each test starts.
	 * The recording is started within this method.
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	@Override
	public void onTestStart(ITestResult result) {
		ScreenRecord screenRecordAnnotation = result.getMethod().getConstructorOrMethod().getMethod()
				.getAnnotation(ScreenRecord.class);
		recordingEnabled = screenRecordAnnotation != null
				&& screenRecordAnnotation.enabled();

		if (recordingEnabled) {
			try {
				MonteScreenRecorder
						.startRecording(result.getMethod().getConstructorOrMethod().getMethod()
						.getName());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Override method to be executed after each test passes.
	 * The recording is stopped within this method and the recorded file is deleted.
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	@Override
	public void onTestSuccess(ITestResult result) {

		ScreenRecord screenRecordAnnotation = result.getMethod().getConstructorOrMethod().getMethod()
				.getAnnotation(ScreenRecord.class);
		recordingEnabled = screenRecordAnnotation != null
				&& screenRecordAnnotation.enabled();

		if (recordingEnabled) {
			try {
				MonteScreenRecorder.stopRecording();
			} catch (Exception e) {
				e.printStackTrace();
			}

			try {
				MonteScreenRecorder.deleteRecording(result.getMethod().getConstructorOrMethod().getMethod()
						.getName());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Override method to be executed after each test fails.
	 * The recording is stopped within this method.
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	@Override
	public void onTestFailure(ITestResult result) {
		ScreenRecord screenRecordAnnotation = result.getMethod().getConstructorOrMethod().getMethod()
				.getAnnotation(ScreenRecord.class);
		recordingEnabled = screenRecordAnnotation != null
				&& screenRecordAnnotation.enabled();

		if (recordingEnabled) {
			try {
				MonteScreenRecorder.stopRecording();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Override method to be executed after each test is skipped.
	 * The recording is stopped within this method and the recorded file is deleted.
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	@Override
	public void onTestSkipped(ITestResult result) {
		ScreenRecord screenRecordAnnotation = result.getMethod().getConstructorOrMethod().getMethod()
				.getAnnotation(ScreenRecord.class);
		recordingEnabled = screenRecordAnnotation != null
				&& screenRecordAnnotation.enabled();

		if (recordingEnabled) {
			try {
				MonteScreenRecorder.stopRecording();
			} catch (Exception e) {
				e.printStackTrace();
			}

			try {
				MonteScreenRecorder.deleteRecording(result.getMethod().getConstructorOrMethod().getMethod()
						.getName());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}