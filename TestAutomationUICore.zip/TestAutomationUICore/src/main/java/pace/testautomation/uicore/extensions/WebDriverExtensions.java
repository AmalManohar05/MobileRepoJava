package pace.testautomation.uicore.extensions;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.function.Supplier;
import java.util.ArrayList;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import pace.testautomation.uicore.utilities.Locator;
import pace.testautomation.uicore.utilities.UiFrameworkSupport;

import static org.openqa.selenium.support.locators.RelativeLocator.with;

/**
 * WebDriverExtensions class containing wrapper methods for the active web
 * driver instance
 * 
 * @author PACE Team
 * @version 1.0.0
 * @since 2023-03-01
 */
public class WebDriverExtensions {

	static {
		UiFrameworkSupport.FrameworkExpiryDateCheckWithoutWarning();
	}

	/**
	 * Get the current session id
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * String sessionId = WebDriverExtensions.getCurrentSessionId(_browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * @return Current session id
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static String getCurrentSessionId(RemoteWebDriver driver) {
		return driver.getSessionId().toString();
	}

	/**
	 * Waiting the execution until the page loads completely.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForPageLoaded(_browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForPageLoaded(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		wait.until((ExpectedCondition<Boolean>) wd -> ((JavascriptExecutor) wd)
				.executeScript("return document.readyState").equals("complete"));
	}

	/**
	 * Waiting the execution until the page loads completely.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForPageLoaded(_browser.webDriver, 100);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param timeout : Max time to wait for the condition
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForPageLoaded(WebDriver driver, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		wait.until((ExpectedCondition<Boolean>) wd -> ((JavascriptExecutor) wd)
				.executeScript("return document.readyState").equals("complete"));
	}	

	/**
	 * Wait for current url to contain expected text
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForUrlContains(_browser.webDriver, "/HomePage");
	 * }
	 * </pre>
	 * 
	 * @param driver   : The current WebDriver instance
	 * @param urlValue : The expected text in the url
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForUrlContains(WebDriver driver, String urlValue) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		wait.until(ExpectedConditions.urlContains(urlValue));
	}
	
	/**
	 * Wait for the current url to match the given expression
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForUrlMatches(_browser.webDriver, ".*google.*");
	 * }
	 * </pre>
	 * 
	 * @param driver   : The current WebDriver instance
	 * @param urlValue : The expected expression to be present in the url
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForUrlMatches(WebDriver driver, String urlValue) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		wait.until(ExpectedConditions.urlMatches(urlValue));
	}

	/**
	 * Wait for the current url to be the given value
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForUrlToBe(_browser.webDriver, "https://www.google.com/");
	 * }
	 * </pre>
	 * 
	 * @param driver   : The current WebDriver instance
	 * @param urlValue : The expected url
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForUrlToBe(WebDriver driver, String urlValue) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		wait.until(ExpectedConditions.urlToBe(urlValue));
	}	

	/**
	 * Wait for the current title to contain the given text
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForTitleContains(_browser.webDriver, "Google");
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * @param title  : The text to be present in the title
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForTitleContains(WebDriver driver, String title) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		wait.until(ExpectedConditions.titleContains(title));
	}	

	/**
	 * Wait for text to be present in element value
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForTextToBePresentInElementValue(_browser.webDriver, LoginUsernameTextbox,
	 * 		"user@test.in");
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The element who's value attribute is being checked
	 * @param text    : The text to be present in the value attribute
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForTextToBePresentInElementValue(WebDriver driver, WebElement element, String text) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		wait.until(ExpectedConditions.textToBePresentInElementValue(element, text));
	}

	/**
	 * Wait for text to be present in element value
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForTextToBePresentInElementValue(_browser.webDriver, LoginUsernameTextbox,
	 * 		"user@test.in");
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The supplier for the element who's value attribute is being
	 *                checked
	 * @param text    : The text to be present in the value attribute
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForTextToBePresentInElementValue(WebDriver driver, Supplier<WebElement> element,
			String text) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		wait.until(ExpectedConditions.textToBePresentInElementValue(element.get(), text));
	}

	/**
	 * Wait for staleness of element.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForStalenessOf(_browser.webDriver, LoginButton);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The element who's staleness is being checked
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForStalenessOf(WebDriver driver, WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		wait.until(ExpectedConditions.stalenessOf(element));
	}

	/**
	 * Wait for staleness of element.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForStalenessOf(_browser.webDriver, LoginButton);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The supplier of the element who's staleness is being checked
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForStalenessOf(WebDriver driver, Supplier<WebElement> element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		wait.until(ExpectedConditions.stalenessOf(element.get()));
	}

	/**
	 * To get the page source of the last loaded page
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * String pageSource = WebDriverExtensions.getPageSource(_browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * @return Page source details as string
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static String getPageSource(WebDriver driver) {
		return driver.getPageSource();
	}

	/**
	 * Wait for text to be present in element value
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForTextToBePresentInElementValue(_browser.webDriver, _loginUsernameTextboxLocator,
	 * 		"user@test.in", Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver      : The current WebDriver instance
	 * @param element     : The string locator value of the element who's value
	 *                    attribute is being checked
	 * @param text        : The text to be present in the value attribute
	 * @param locatorType : The locator type enum value for locating the element
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForTextToBePresentInElementValue(WebDriver driver, String element, String text,
			Enum<?> locatorType) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		if (locatorType.equals(Locator.LocatorType.Xpath)) {
			wait.until(ExpectedConditions.textToBePresentInElementValue(By.xpath(element), text));
		} else if (locatorType.equals(Locator.LocatorType.Id)) {
			wait.until(ExpectedConditions.textToBePresentInElementValue(By.id(element), text));
		} else if (locatorType.equals(Locator.LocatorType.Name)) {
			wait.until(ExpectedConditions.textToBePresentInElementValue(By.name(element), text));
		} else if (locatorType.equals(Locator.LocatorType.ClassName)) {
			wait.until(ExpectedConditions.textToBePresentInElementValue(By.className(element), text));
		} else if (locatorType.equals(Locator.LocatorType.CssSelector)) {
			wait.until(ExpectedConditions.textToBePresentInElementValue(By.cssSelector(element), text));
		} else if (locatorType.equals(Locator.LocatorType.LinkText)) {
			wait.until(ExpectedConditions.textToBePresentInElementValue(By.linkText(element), text));
		} else if (locatorType.equals(Locator.LocatorType.PartialLinkText)) {
			wait.until(ExpectedConditions.textToBePresentInElementValue(By.partialLinkText(element), text));
		} else if (locatorType.equals(Locator.LocatorType.TagName)) {
			wait.until(ExpectedConditions.textToBePresentInElementValue(By.tagName(element), text));
		} else {
			throw new NoSuchElementException();
		}
	}

	/**
	 * Wait for text to be present in element value
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForTextToBePresentInElementValue(_browser.webDriver, _loginUsernameTextboxLocator,
	 * 		"user@test.in", Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver      : The current WebDriver instance
	 * @param element     : The supplier of the string locator value for the element
	 *                    who's value attribute is being checked
	 * @param text        : The text to be present in the element's value attribute
	 * @param locatorType : The locator type enum value for locating the element
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForTextToBePresentInElementValue(WebDriver driver, Supplier<String> element, String text,
			Enum<?> locatorType) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		if (locatorType.equals(Locator.LocatorType.Xpath)) {
			wait.until(ExpectedConditions.textToBePresentInElementValue(By.xpath(element.get()), text));
		} else if (locatorType.equals(Locator.LocatorType.Id)) {
			wait.until(ExpectedConditions.textToBePresentInElementValue(By.id(element.get()), text));
		} else if (locatorType.equals(Locator.LocatorType.Name)) {
			wait.until(ExpectedConditions.textToBePresentInElementValue(By.name(element.get()), text));
		} else if (locatorType.equals(Locator.LocatorType.ClassName)) {
			wait.until(ExpectedConditions.textToBePresentInElementValue(By.className(element.get()), text));
		} else if (locatorType.equals(Locator.LocatorType.CssSelector)) {
			wait.until(ExpectedConditions.textToBePresentInElementValue(By.cssSelector(element.get()), text));
		} else if (locatorType.equals(Locator.LocatorType.LinkText)) {
			wait.until(ExpectedConditions.textToBePresentInElementValue(By.linkText(element.get()), text));
		} else if (locatorType.equals(Locator.LocatorType.PartialLinkText)) {
			wait.until(ExpectedConditions.textToBePresentInElementValue(By.partialLinkText(element.get()), text));
		} else if (locatorType.equals(Locator.LocatorType.TagName)) {
			wait.until(ExpectedConditions.textToBePresentInElementValue(By.tagName(element.get()), text));
		} else {
			throw new NoSuchElementException();
		}
	}

	/**
	 * Wait for frame to be available and switch to it
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForFrameToBeAvailableAndSwitchToIt(_browser.webDriver, _dataFormLocator,
	 * 		Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver      : The current WebDriver instance
	 * @param element     : The string locator value for the frame element
	 * @param locatorType : The locator type enum value for locating the element
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForFrameToBeAvailableAndSwitchToIt(WebDriver driver, String element, Enum<?> locatorType) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		if (locatorType.equals(Locator.LocatorType.Xpath)) {
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath(element)));
		} else if (locatorType.equals(Locator.LocatorType.Id)) {
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id(element)));
		} else if (locatorType.equals(Locator.LocatorType.Name)) {
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.name(element)));
		} else if (locatorType.equals(Locator.LocatorType.ClassName)) {
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.className(element)));
		} else if (locatorType.equals(Locator.LocatorType.CssSelector)) {
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.cssSelector(element)));
		} else if (locatorType.equals(Locator.LocatorType.LinkText)) {
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.linkText(element)));
		} else if (locatorType.equals(Locator.LocatorType.PartialLinkText)) {
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.partialLinkText(element)));
		} else if (locatorType.equals(Locator.LocatorType.TagName)) {
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.tagName(element)));
		} else {
			throw new NoSuchElementException();
		}
	}

	/**
	 * Wait for frame to be available and switch to it
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForFrameToBeAvailableAndSwitchToIt(_browser.webDriver, _dataFormLocator,
	 * 		Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver      : The current WebDriver instance
	 * @param element     : The supplier of the string locator value for the frame
	 *                    element
	 * @param locatorType : The locator type enum value for locating the element
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForFrameToBeAvailableAndSwitchToIt(WebDriver driver, Supplier<String> element,
			Enum<?> locatorType) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		if (locatorType.equals(Locator.LocatorType.Xpath)) {
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.Id)) {
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.Name)) {
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.name(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.ClassName)) {
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.className(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.CssSelector)) {
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.cssSelector(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.LinkText)) {
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.linkText(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.PartialLinkText)) {
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.partialLinkText(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.TagName)) {
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.tagName(element.get())));
		} else {
			throw new NoSuchElementException();
		}
	}

	/**
	 * Execution wait for an element to be present for up to 60 seconds and throws
	 * exception.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForElement(_browser.webDriver, _loginButtonLocator, Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver      : The current WebDriver instance
	 * @param element     : The string locator value for the element who's presence
	 *                    is being checked
	 * @param locatorType : The locator type enum value for locating the element
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForElement(WebDriver driver, String element, Enum<?> locatorType) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		if (locatorType.equals(Locator.LocatorType.Xpath)) {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(element)));
		} else if (locatorType.equals(Locator.LocatorType.Id)) {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(element)));
		} else if (locatorType.equals(Locator.LocatorType.Name)) {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.name(element)));
		} else if (locatorType.equals(Locator.LocatorType.ClassName)) {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.className(element)));
		} else if (locatorType.equals(Locator.LocatorType.CssSelector)) {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(element)));
		} else if (locatorType.equals(Locator.LocatorType.LinkText)) {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(element)));
		} else if (locatorType.equals(Locator.LocatorType.PartialLinkText)) {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(element)));
		} else if (locatorType.equals(Locator.LocatorType.TagName)) {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName(element)));
		} else {
			throw new NoSuchElementException();
		}
	}

	/**
	 * Execution wait for an element to be present for up to 60 seconds and throws
	 * exception.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForElement(_browser.webDriver, _loginButtonLocator, Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver      : The current WebDriver instance
	 * @param element     : The supplier of the string locator value for the element
	 *                    who's presence is being checked
	 * @param locatorType : The locator type enum value for locating the element
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForElement(WebDriver driver, Supplier<String> element, Enum<?> locatorType) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		if (locatorType.equals(Locator.LocatorType.Xpath)) {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.Id)) {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.Name)) {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.name(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.ClassName)) {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.className(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.CssSelector)) {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.LinkText)) {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.PartialLinkText)) {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.TagName)) {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName(element.get())));
		} else {
			throw new NoSuchElementException();
		}
	}

	/**
	 * Wait until element to be click for 60 seconds
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForElementClickable(_browser.webDriver, LoginButton);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The element who's enabled state is being checked
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForElementClickable(WebDriver driver, WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		try {
			wait.until(ExpectedConditions.elementToBeClickable(element));
		} catch (Exception e) {
			throw new NoSuchElementException();
		}
	}

	/**
	 * Wait until element to be click for 60 seconds
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForElementClickable(_browser.webDriver, LoginButton);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The supplier of the element who's enabled state is being
	 *                checked
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForElementClickable(WebDriver driver, Supplier<WebElement> element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		try {
			wait.until(ExpectedConditions.elementToBeClickable(element.get()));
		} catch (Exception e) {
			throw new NoSuchElementException();
		}
	}

	/**
	 * Wait until element to be click for 60 seconds
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForElementClickable(_browser.webDriver, _loginButtonLocator, Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver      : The current WebDriver instance
	 * @param element     : The string locator value for the element who's enabled
	 *                    state is being checked
	 * @param locatorType : The locator type enum value for locating the element
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForElementClickable(WebDriver driver, String element, Enum<?> locatorType) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		if (locatorType.equals(Locator.LocatorType.Xpath)) {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(element)));
		} else if (locatorType.equals(Locator.LocatorType.Id)) {
			wait.until(ExpectedConditions.elementToBeClickable(By.id(element)));
		} else if (locatorType.equals(Locator.LocatorType.Name)) {
			wait.until(ExpectedConditions.elementToBeClickable(By.name(element)));
		} else if (locatorType.equals(Locator.LocatorType.ClassName)) {
			wait.until(ExpectedConditions.elementToBeClickable(By.className(element)));
		} else if (locatorType.equals(Locator.LocatorType.CssSelector)) {
			wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(element)));
		} else if (locatorType.equals(Locator.LocatorType.LinkText)) {
			wait.until(ExpectedConditions.elementToBeClickable(By.linkText(element)));
		} else if (locatorType.equals(Locator.LocatorType.PartialLinkText)) {
			wait.until(ExpectedConditions.elementToBeClickable(By.partialLinkText(element)));
		} else if (locatorType.equals(Locator.LocatorType.TagName)) {
			wait.until(ExpectedConditions.elementToBeClickable(By.tagName(element)));
		} else {
			throw new NoSuchElementException();
		}
	}

	/**
	 * Wait until element to be click for 60 seconds
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForElementClickable(_browser.webDriver, _loginButtonLocator, Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver      : The current WebDriver instance
	 * @param element     : The supplier of the string locator value for the element
	 *                    who's enabled state is being checked
	 * @param locatorType : The locator type enum value for locating the element
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForElementClickable(WebDriver driver, Supplier<String> element, Enum<?> locatorType) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		if (locatorType.equals(Locator.LocatorType.Xpath)) {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.Id)) {
			wait.until(ExpectedConditions.elementToBeClickable(By.id(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.Name)) {
			wait.until(ExpectedConditions.elementToBeClickable(By.name(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.ClassName)) {
			wait.until(ExpectedConditions.elementToBeClickable(By.className(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.CssSelector)) {
			wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.LinkText)) {
			wait.until(ExpectedConditions.elementToBeClickable(By.linkText(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.PartialLinkText)) {
			wait.until(ExpectedConditions.elementToBeClickable(By.partialLinkText(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.TagName)) {
			wait.until(ExpectedConditions.elementToBeClickable(By.tagName(element.get())));
		} else {
			throw new NoSuchElementException();
		}
	}

	/**
	 * Wait until element to be visible for 60 seconds
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForElementIsVisible(_browser.webDriver, _loginButtonLocator, Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver      : The current WebDriver instance
	 * @param element     : The string locator value for the element who's
	 *                    visibility is being checked
	 * @param locatorType : The locator type enum value for locating the element
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForElementIsVisible(WebDriver driver, String element, Enum<?> locatorType) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		if (locatorType.equals(Locator.LocatorType.Xpath)) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element)));
		} else if (locatorType.equals(Locator.LocatorType.Id)) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(element)));
		} else if (locatorType.equals(Locator.LocatorType.Name)) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.name(element)));
		} else if (locatorType.equals(Locator.LocatorType.ClassName)) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(element)));
		} else if (locatorType.equals(Locator.LocatorType.CssSelector)) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(element)));
		} else if (locatorType.equals(Locator.LocatorType.LinkText)) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(element)));
		} else if (locatorType.equals(Locator.LocatorType.PartialLinkText)) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.partialLinkText(element)));
		} else if (locatorType.equals(Locator.LocatorType.TagName)) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName(element)));
		} else {
			throw new NoSuchElementException();
		}
	}

	/**
	 * Wait until element to be visible for 60 seconds
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForElementIsVisible(_browser.webDriver, _loginButtonLocator, Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver      : The current WebDriver instance
	 * @param element     : The supplier of the string locator value for the element
	 *                    who's visibility is being checked
	 * @param locatorType : The locator type enum value for locating the element
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForElementIsVisible(WebDriver driver, Supplier<String> element, Enum<?> locatorType) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		if (locatorType.equals(Locator.LocatorType.Xpath)) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.Id)) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.Name)) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.name(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.ClassName)) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.CssSelector)) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.LinkText)) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.PartialLinkText)) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.partialLinkText(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.TagName)) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName(element.get())));
		} else {
			throw new NoSuchElementException();
		}
	}

	/**
	 * Wait until element to be invisible for 60 seconds
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForElementInvisible(_browser.webDriver, _loginButtonLocator, Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver      : The current WebDriver instance
	 * @param element     : The string locator value for the element who's
	 *                    invisibility is being checked
	 * @param locatorType : The locator type enum value for locating the element
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForElementInvisible(WebDriver driver, String element, Enum<?> locatorType) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		if (locatorType.equals(Locator.LocatorType.Xpath)) {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(element)));
		} else if (locatorType.equals(Locator.LocatorType.Id)) {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id(element)));
		} else if (locatorType.equals(Locator.LocatorType.Name)) {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.name(element)));
		} else if (locatorType.equals(Locator.LocatorType.ClassName)) {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className(element)));
		} else if (locatorType.equals(Locator.LocatorType.CssSelector)) {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(element)));
		} else if (locatorType.equals(Locator.LocatorType.LinkText)) {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.linkText(element)));
		} else if (locatorType.equals(Locator.LocatorType.PartialLinkText)) {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.partialLinkText(element)));
		} else if (locatorType.equals(Locator.LocatorType.TagName)) {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.tagName(element)));
		} else {
			throw new NoSuchElementException();
		}
	}

	/**
	 * Wait until element to be Invisible for 60 seconds using web element.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.waitForElementInvisible(_browser.webDriver, _loginButtonLocator, Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver      : The current WebDriver instance
	 * @param element     : The supplier of the string locator value for the element
	 *                    who's invisibility is being checked
	 * @param locatorType : The locator type enum value for locating the element
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void waitForElementInvisible(WebDriver driver, Supplier<String> element, Enum<?> locatorType) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		if (locatorType.equals(Locator.LocatorType.Xpath)) {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.Id)) {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.Name)) {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.name(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.ClassName)) {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.CssSelector)) {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.LinkText)) {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.linkText(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.PartialLinkText)) {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.partialLinkText(element.get())));
		} else if (locatorType.equals(Locator.LocatorType.TagName)) {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.tagName(element.get())));
		} else {
			throw new NoSuchElementException();
		}
	}

	/**
	 * Check the element exist in the DOM.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.isElementExists(_browser.webDriver, _loginButtonLocator, Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver      : The current WebDriver instance
	 * @param element     : The string locator value for the element who's presence
	 *                    is being checked
	 * @param locatorType : The locator type enum value for locating the element
	 * @return Whether or not the element is present in the DOM (true/false)
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static boolean isElementExists(WebDriver driver, String element, Enum<?> locatorType) {
		try {
			if (locatorType.equals(Locator.LocatorType.Xpath)) {
				driver.findElement(By.xpath((element)));
			} else if (locatorType.equals(Locator.LocatorType.Id)) {
				driver.findElement(By.id((element)));
			} else if (locatorType.equals(Locator.LocatorType.Name)) {
				driver.findElement(By.name((element)));
			} else if (locatorType.equals(Locator.LocatorType.ClassName)) {
				driver.findElement(By.className((element)));
			} else if (locatorType.equals(Locator.LocatorType.CssSelector)) {
				driver.findElement(By.cssSelector((element)));
			} else if (locatorType.equals(Locator.LocatorType.LinkText)) {
				driver.findElement(By.linkText((element)));
			} else if (locatorType.equals(Locator.LocatorType.PartialLinkText)) {
				driver.findElement(By.partialLinkText((element)));
			} else if (locatorType.equals(Locator.LocatorType.TagName)) {
				driver.findElement(By.tagName((element)));
			} else {
				throw new NoSuchElementException();
			}
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Check the element exist in the DOM.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.isElementExists(_browser.webDriver, _loginButtonLocator, Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver      : The current WebDriver instance
	 * @param element     : The supplier of the string locator value for the element
	 *                    who's presence is being checked
	 * @param locatorType : The locator type enum value for locating the element
	 * @return Whether or not the element is present in the DOM (true/false)
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static boolean isElementExists(WebDriver driver, Supplier<String> element, Enum<?> locatorType) {
		try {
			if (locatorType.equals(Locator.LocatorType.Xpath)) {
				driver.findElement(By.xpath((element.get())));
			} else if (locatorType.equals(Locator.LocatorType.Id)) {
				driver.findElement(By.id((element.get())));
			} else if (locatorType.equals(Locator.LocatorType.Name)) {
				driver.findElement(By.name((element.get())));
			} else if (locatorType.equals(Locator.LocatorType.ClassName)) {
				driver.findElement(By.className((element.get())));
			} else if (locatorType.equals(Locator.LocatorType.CssSelector)) {
				driver.findElement(By.cssSelector((element.get())));
			} else if (locatorType.equals(Locator.LocatorType.LinkText)) {
				driver.findElement(By.linkText((element.get())));
			} else if (locatorType.equals(Locator.LocatorType.PartialLinkText)) {
				driver.findElement(By.partialLinkText((element.get())));
			} else if (locatorType.equals(Locator.LocatorType.TagName)) {
				driver.findElement(By.tagName((element.get())));
			} else {
				throw new NoSuchElementException();
			}
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Check the element displayed in UI.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.isElementDisplayed(_browser.webDriver, _loginButtonLocator, Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver      : The current WebDriver instance
	 * @param element     : The string locator value for the element who's
	 *                    visibility is being checked
	 * @param locatorType : The locator type enum value for locating the element
	 * @return Whether or not the element is displayed in the UI (true/false)
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static boolean isElementDisplayed(WebDriver driver, String element, Enum<?> locatorType) {
		boolean isDisplayed = false;
		try {
			if (locatorType.equals(Locator.LocatorType.Xpath)) {
				isDisplayed = driver.findElement(By.xpath((element))).isDisplayed();
			} else if (locatorType.equals(Locator.LocatorType.Id)) {
				isDisplayed = driver.findElement(By.id((element))).isDisplayed();
			} else if (locatorType.equals(Locator.LocatorType.Name)) {
				isDisplayed = driver.findElement(By.name((element))).isDisplayed();
			} else if (locatorType.equals(Locator.LocatorType.ClassName)) {
				isDisplayed = driver.findElement(By.className((element))).isDisplayed();
			} else if (locatorType.equals(Locator.LocatorType.CssSelector)) {
				isDisplayed = driver.findElement(By.cssSelector((element))).isDisplayed();
			} else if (locatorType.equals(Locator.LocatorType.LinkText)) {
				isDisplayed = driver.findElement(By.linkText((element))).isDisplayed();
			} else if (locatorType.equals(Locator.LocatorType.PartialLinkText)) {
				isDisplayed = driver.findElement(By.partialLinkText((element))).isDisplayed();
			} else if (locatorType.equals(Locator.LocatorType.TagName)) {
				isDisplayed = driver.findElement(By.tagName((element))).isDisplayed();
			} else {
				throw new NoSuchElementException();
			}
			return isDisplayed;
		} catch (Exception e) {
			return isDisplayed;
		}
	}

	/**
	 * Check the element displayed in UI.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.isElementDisplayed(_browser.webDriver, _loginButtonLocator, Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver      : The current WebDriver instance
	 * @param element     : The supplier of the string locator value for the element
	 *                    who's visibility is being checked
	 * @param locatorType : The locator type enum value for locating the element
	 * @return Whether or not the element is displayed in the UI (true/false)
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static boolean isElementDisplayed(WebDriver driver, Supplier<String> element, Enum<?> locatorType) {
		boolean isDisplayed = false;
		try {
			if (locatorType.equals(Locator.LocatorType.Xpath)) {
				isDisplayed = driver.findElement(By.xpath((element.get()))).isDisplayed();
			} else if (locatorType.equals(Locator.LocatorType.Id)) {
				isDisplayed = driver.findElement(By.id((element.get()))).isDisplayed();
			} else if (locatorType.equals(Locator.LocatorType.Name)) {
				isDisplayed = driver.findElement(By.name((element.get()))).isDisplayed();
			} else if (locatorType.equals(Locator.LocatorType.ClassName)) {
				isDisplayed = driver.findElement(By.className((element.get()))).isDisplayed();
			} else if (locatorType.equals(Locator.LocatorType.CssSelector)) {
				isDisplayed = driver.findElement(By.cssSelector((element.get()))).isDisplayed();
			} else if (locatorType.equals(Locator.LocatorType.LinkText)) {
				isDisplayed = driver.findElement(By.linkText((element.get()))).isDisplayed();
			} else if (locatorType.equals(Locator.LocatorType.PartialLinkText)) {
				isDisplayed = driver.findElement(By.partialLinkText((element.get()))).isDisplayed();
			} else if (locatorType.equals(Locator.LocatorType.TagName)) {
				isDisplayed = driver.findElement(By.tagName((element.get()))).isDisplayed();
			} else {
				throw new NoSuchElementException();
			}
			return isDisplayed;
		} catch (Exception e) {
			return isDisplayed;
		}
	}

	/**
	 * Drag and drop.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.dragAndDrop(_browser.webDriver, ImageElement, TrashBinElement);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * @param source : The element to be moved
	 * @param target : The element to which the source element is moved
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void dragAndDrop(WebDriver driver, WebElement source, WebElement target) {
		Actions actions = new Actions(driver);
		actions.clickAndHold(source).moveToElement(target).dragAndDrop(source, target).build().perform();
	}

	/**
	 * Drag and drop.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.dragAndDrop(_browser.webDriver, ImageElement, TrashBinElement);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * @param source : The supplier of the element to be moved
	 * @param target : The supplier of the element to which the source element is
	 *               moved
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void dragAndDrop(WebDriver driver, Supplier<WebElement> source, Supplier<WebElement> element) {
		Actions actions = new Actions(driver);
		actions.clickAndHold(source.get()).moveToElement(element.get()).dragAndDrop(source.get(), element.get()).build()
				.perform();
	}

	/**
	 * Drag and drop with offset
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.dragAndDrop(_browser.webDriver, ImageElement, 100, 150);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param source  : The element to be moved
	 * @param offsetX : The x coordinate distance to be moved
	 * @param offsetY : The y coordinate distance to be moved
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void dragAndDrop(WebDriver driver, WebElement source, int offsetX, int offsetY) {
		Actions actions = new Actions(driver);
		actions.click(source).moveByOffset(offsetX, offsetY).release().build().perform();
	}

	/**
	 * Drag and drop with offset
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.dragAndDrop(_browser.webDriver, ImageElement, 100, 150);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param source  : The supplier of the element to be moved
	 * @param offsetX : The x coordinate distance to be moved
	 * @param offsetY : The y coordinate distance to be moved
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void dragAndDrop(WebDriver driver, Supplier<WebElement> source, int offsetX, int offsetY) {
		Actions actions = new Actions(driver);
		actions.click(source.get()).moveByOffset(offsetX, offsetY).release().build().perform();
	}

	/**
	 * Move to element and click using action class
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.moveToElementAndClick(_browser.webDriver, AddButton);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The element to be clicked
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void moveToElementAndClick(WebDriver driver, WebElement element) {
		Actions actions = new Actions(driver);
		actions.moveToElement(element).click().perform();
	}

	/**
	 * Move to element and click using action class
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.moveToElementAndClick(_browser.webDriver, AddButton);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The supplier of the element to be clicked
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void moveToElementAndClick(WebDriver driver, Supplier<WebElement> element) {
		Actions actions = new Actions(driver);
		actions.moveToElement(element.get()).click().perform();
	}

	/**
	 * Mouse Hover using action class
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.mouseHover(_browser.webDriver, AddButton);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The element to which mouse is hovered
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void mouseHover(WebDriver driver, WebElement element) {
		Actions actions = new Actions(driver);
		actions.moveToElement(element).perform();
	}

	/**
	 * Mouse Hover using action class
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.mouseHover(_browser.webDriver, AddButton);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The supplier of the element to which mouse is hovered
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void mouseHover(WebDriver driver, Supplier<WebElement> element) {
		Actions actions = new Actions(driver);
		actions.moveToElement(element.get()).perform();
	}

	/**
	 * Double Click using action class
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.doubleClick(_browser.webDriver, AcceptButton);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The element to be clicked
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void doubleClick(WebDriver driver, WebElement element) {
		Actions actions = new Actions(driver);
		actions.doubleClick(element).perform();
	}

	/**
	 * Double Click using action class
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.doubleClick(_browser.webDriver, AcceptButton);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The supplier of the element to be clicked
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void doubleClick(WebDriver driver, Supplier<WebElement> element) {
		Actions actions = new Actions(driver);
		actions.doubleClick(element.get()).perform();
	}

	/**
	 * Send keys using action class
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.sendKeysUsingActions(_browser.webDriver, LoginUsernameTextbox, "user@test.in");
	 * }
	 * </pre>
	 * 
	 * @param driver     : The current WebDriver instance
	 * @param element    : The element to which keys are send
	 * @param keysToSend : Keys to be sent
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void sendKeysUsingActions(WebDriver driver, WebElement element, String keysToSend) {
		Actions actions = new Actions(driver);
		actions.sendKeys(element, keysToSend).perform();
	}

	/**
	 * Send keys using action class
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.sendKeysUsingActions(_browser.webDriver, LoginUsernameTextbox, "user@test.in");
	 * }
	 * </pre>
	 * 
	 * @param driver     : The current WebDriver instance
	 * @param element    : The supplier of the element to which keys are send
	 * @param keysToSend : Keys to be sent
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void sendKeysUsingActions(WebDriver driver, Supplier<WebElement> element, String keysToSend) {
		Actions actions = new Actions(driver);
		actions.sendKeys(element.get(), keysToSend).perform();
	}

	/**
	 * Open new tab.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.openNewBrowserTab(_browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void openNewBrowserTab(WebDriver driver) {
		((JavascriptExecutor) driver).executeScript("window.open();");
	}

	/**
	 * Redirect the browser to a new url
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.javaScriptWindowLocation(_browser.webDriver, "https://www.google.com/");
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * @param url    : The url to which the window is redirected
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void javaScriptWindowLocation(WebDriver driver, String url) {
		((JavascriptExecutor) driver).executeScript("window.location ='" + url + "'");
	}

	/**
	 * Switch to frame.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.switchToFrame(_browser.webDriver, _frameLocator, Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver      : The current WebDriver instance
	 * @param element     : The string locator value for the frame element
	 * @param locatorType : The locator type enum value for locating the element
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void switchToFrame(WebDriver driver, String element, Enum<?> locatorType) {
		if (locatorType.equals(Locator.LocatorType.Xpath)) {
			driver.switchTo().frame(driver.findElement(By.xpath((element))));
		} else if (locatorType.equals(Locator.LocatorType.Id)) {
			driver.switchTo().frame(driver.findElement(By.id((element))));
		} else if (locatorType.equals(Locator.LocatorType.Name)) {
			driver.switchTo().frame(driver.findElement(By.name((element))));
		} else if (locatorType.equals(Locator.LocatorType.TagName)) {
			driver.switchTo().frame(driver.findElement(By.tagName((element))));
		} else {
			throw new NoSuchFrameException(element, null);
		}
	}

	/**
	 * Switch to frame.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.switchToFrame(_browser.webDriver, _frameLocator, Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver      : The current WebDriver instance
	 * @param element     : The supplier of the string locator value for the frame
	 *                    element
	 * @param locatorType : The locator type enum value for locating the element
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void switchToFrame(WebDriver driver, Supplier<String> element, Enum<?> locatorType) {
		if (locatorType.equals(Locator.LocatorType.Xpath)) {
			driver.switchTo().frame(driver.findElement(By.xpath((element.get()))));
		} else if (locatorType.equals(Locator.LocatorType.Id)) {
			driver.switchTo().frame(driver.findElement(By.id((element.get()))));
		} else if (locatorType.equals(Locator.LocatorType.Name)) {
			driver.switchTo().frame(driver.findElement(By.name((element.get()))));
		} else if (locatorType.equals(Locator.LocatorType.TagName)) {
			driver.switchTo().frame(driver.findElement(By.tagName((element.get()))));
		} else {
			throw new NoSuchFrameException(element.get(), null);
		}
	}

	/**
	 * Locate the element.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.locateElement(_browser.webDriver, _loginButtonLocator, Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver          : The current WebDriver instance
	 * @param elementToLocate : The string locator value for the element to be
	 *                        located
	 * @param locatorType     : The locator type enum value for locating the element
	 * @return Webelement based on locator type
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static WebElement locateElement(WebDriver driver, String elementToLocate, Enum<?> locatorType) {
		WebElement element = null;
		if (locatorType.equals(Locator.LocatorType.Xpath)) {
			element = driver.findElement(By.xpath((elementToLocate)));
		} else if (locatorType.equals(Locator.LocatorType.Id)) {
			element = driver.findElement(By.id((elementToLocate)));
		} else if (locatorType.equals(Locator.LocatorType.Name)) {
			element = driver.findElement(By.name((elementToLocate)));
		} else if (locatorType.equals(Locator.LocatorType.LinkText)) {
			element = driver.findElement(By.linkText((elementToLocate)));
		} else if (locatorType.equals(Locator.LocatorType.PartialLinkText)) {
			element = driver.findElement(By.partialLinkText((elementToLocate)));
		} else if (locatorType.equals(Locator.LocatorType.CssSelector)) {
			element = driver.findElement(By.cssSelector((elementToLocate)));
		} else if (locatorType.equals(Locator.LocatorType.ClassName)) {
			element = driver.findElement(By.className((elementToLocate)));
		} else if (locatorType.equals(Locator.LocatorType.TagName)) {
			element = driver.findElement(By.tagName((elementToLocate)));
		} else {
			throw new NoSuchElementException();
		}

		return element;
	}

	/**
	 * Locate the element.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.locateElement(_browser.webDriver, _loginButtonLocator, Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver          : The current WebDriver instance
	 * @param elementToLocate : The supplier of the string locator value for the
	 *                        element to be located
	 * @param locatorType     : The locator type enum value for locating the element
	 * @return Webelement based on locator type
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static WebElement locateElement(WebDriver driver, Supplier<String> elementToLocate, Enum<?> locatorType) {
		WebElement element = null;
		if (locatorType.equals(Locator.LocatorType.Xpath)) {
			element = driver.findElement(By.xpath((elementToLocate.get())));
		} else if (locatorType.equals(Locator.LocatorType.Id)) {
			element = driver.findElement(By.id((elementToLocate.get())));
		} else if (locatorType.equals(Locator.LocatorType.Name)) {
			element = driver.findElement(By.name((elementToLocate.get())));
		} else if (locatorType.equals(Locator.LocatorType.LinkText)) {
			element = driver.findElement(By.linkText((elementToLocate.get())));
		} else if (locatorType.equals(Locator.LocatorType.PartialLinkText)) {
			element = driver.findElement(By.partialLinkText((elementToLocate.get())));
		} else if (locatorType.equals(Locator.LocatorType.CssSelector)) {
			element = driver.findElement(By.cssSelector((elementToLocate.get())));
		} else if (locatorType.equals(Locator.LocatorType.ClassName)) {
			element = driver.findElement(By.className((elementToLocate.get())));
		} else if (locatorType.equals(Locator.LocatorType.TagName)) {
			element = driver.findElement(By.tagName((elementToLocate.get())));
		} else {
			throw new NoSuchElementException();
		}

		return element;
	}

	/**
	 * Get web element using java script query
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.getElementUsingQuerySelector(_browser.webDriver, "document.querySelector('[type="submit"]')");
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * @param query  : The java script query to get the web element
	 * @return Webelement after executing the java script
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static WebElement getElementUsingQuerySelector(WebDriver driver, String query) {
		WebElement element;
		JavascriptExecutor javascript = (JavascriptExecutor) driver;
		element = (WebElement) javascript.executeScript("return " + query);
		return element;
	}

	/**
	 * Get web element using java script query
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.getElementUsingQuerySelector(_browser.webDriver, _queryForSinginButton);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * @param query  : The supplier string of the java script query to get the web
	 *               element
	 * @return Webelement after executing the java script
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static WebElement getElementUsingQuerySelector(WebDriver driver, Supplier<String> query) {
		WebElement element;
		JavascriptExecutor javascript = (JavascriptExecutor) driver;
		element = (WebElement) javascript.executeScript("return " + query.get());
		return element;
	}

	/**
	 * Get Web Elements into list using java script Query
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.getElementsIntoListUsingQuerySelector(_browser.webDriver, _queryForHeaderTabs);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * @param query  : The java script query to get all matching web elements into
	 *               list
	 * @return List of web elements using query selector
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	@SuppressWarnings("unchecked")
	public static List<WebElement> getElementsIntoListUsingQuerySelector(WebDriver driver, String query) {
		List<WebElement> element;
		JavascriptExecutor javascript = (JavascriptExecutor) driver;
		element = (List<WebElement>) javascript.executeScript("return " + query);
		return element;
	}

	/**
	 * Get Web Elements into list using java script Query
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.getElementsIntoListUsingQuerySelector(_browser.webDriver, _queryForHeaderTabs);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * @param query  : The supplier of the string java script query to get all
	 *               matching web elements into list
	 * @return List of web elements using query selector
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	@SuppressWarnings("unchecked")
	public static List<WebElement> getElementsIntoListUsingQuerySelector(WebDriver driver, Supplier<String> query) {
		List<WebElement> element;
		JavascriptExecutor javascript = (JavascriptExecutor) driver;
		element = (List<WebElement>) javascript.executeScript("return " + query.get());
		return element;
	}

	/**
	 * Generate locators into list using query selector
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.generateLocatorsIntoListUsingQuerySelector(_browser.webDriver, _queryForHeaderReplacer,
	 * 		"Tabs");
	 * }
	 * </pre>
	 * 
	 * @param driver         : The current WebDriver instance
	 * @param dynamicLocator : The java script query with a 'replacer' value
	 * @param replaceValue   : The value which will replacer the 'replacer' in the
	 *                       dynamic locator
	 * @return Dynamic List of web elements using query selector
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static List<WebElement> generateLocatorsIntoListUsingQuerySelector(WebDriver driver, String dynamicLocator,
			String replaceValue) {
		return getElementsIntoListUsingQuerySelector(driver, dynamicLocator.replace("replacer", replaceValue));
	}

	/**
	 * Generate locators into list using query selector
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.generateLocatorsIntoListUsingQuerySelector(_browser.webDriver, _queryForHeaderReplacer,
	 * 		"Tabs");
	 * }
	 * </pre>
	 * 
	 * @param driver         : The current WebDriver instance
	 * @param dynamicLocator : The supplier string of java script query with a
	 *                       'replacer' value
	 * @param replaceValue   : The value which will replacer the 'replacer' in the
	 *                       dynamic locator
	 * @return Dynamic List of web elements using query selector
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static List<WebElement> generateLocatorsIntoListUsingQuerySelector(WebDriver driver,
			Supplier<String> dynamicLocator, String replaceValue) {
		return getElementsIntoListUsingQuerySelector(driver, dynamicLocator.get().replace("replacer", replaceValue));
	}

	/**
	 * Generate locators using query selector
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.generateLocatorsUsingQuerySelector(_browser.webDriver, _queryForReplacerButton, "SignUp");
	 * }
	 * </pre>
	 * 
	 * @param driver         : The current WebDriver instance
	 * @param dynamicLocator : The string locator value containing 'replacer' part
	 * @param replaceValue   : The dynamic value which will replace the 'replacer'
	 * @return Web element generated using query selector
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static WebElement generateLocatorsUsingQuerySelector(WebDriver driver, String dynamicLocator,
			String replaceValue) {
		return getElementUsingQuerySelector(driver, dynamicLocator.replace("replacer", replaceValue));
	}

	/**
	 * Generate locators using query selector
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.generateLocatorsUsingQuerySelector(_browser.webDriver, _queryForReplacerButton, "SignUp");
	 * }
	 * </pre>
	 * 
	 * @param driver         : The current WebDriver instance
	 * @param dynamicLocator : The supplier of the string locator value containing
	 *                       'replacer' part
	 * @param replaceValue   : The dynamic value which will replace the 'replacer'
	 * @return Web element generated using query selector
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static WebElement generateLocatorsUsingQuerySelector(WebDriver driver, Supplier<String> dynamicLocator,
			String replaceValue) {
		return getElementUsingQuerySelector(driver, dynamicLocator.get().replace("replacer", replaceValue));
	}

	/**
	 * Get all elements in to a list.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.getAllElementsIntoList(_browser.webDriver, _tabHeaderLocator);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The string locator value for the elements
	 * @return List of web elements
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static List<WebElement> getAllElementsIntoList(WebDriver driver, String element) {
		List<WebElement> webElements = driver.findElements(By.xpath(element));
		return webElements;
	}

	/**
	 * Get all elements in to a list.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.getAllElementsIntoList(_browser.webDriver, _tabHeaderLocator);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The supplier of the string locator value for the elements
	 * @return List of web elements
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static List<WebElement> getAllElementsIntoList(WebDriver driver, Supplier<String> element) {
		List<WebElement> webElements = driver.findElements(By.xpath(element.get()));
		return webElements;
	}

	/**
	 * Checks whether horizontal scroll is present.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.isHorizonalScrollPresent(_browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * @return Whether or not horizontal scroll bar is present in the page
	 *         (true/false)
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static boolean isHorizonalScrollPresent(WebDriver driver) {
		JavascriptExecutor javascript = (JavascriptExecutor) driver;
		boolean horzscrollStatus = (Boolean) javascript
				.executeScript("return document.documentElement.scrollWidth>document.documentElement.clientWidth;");
		return horzscrollStatus;
	}

	/**
	 * Checks whether vertical scroll is present.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.isVerticalScrollPresent(_browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * @return Whether or not vertical scroll bar is present in the page
	 *         (true/false)
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static boolean isVerticalScrollPresent(WebDriver driver) {
		JavascriptExecutor javascript = (JavascriptExecutor) driver;
		boolean vertscrollStatus = (Boolean) javascript
				.executeScript("return document.documentElement.scrollHeight>document.documentElement.clientHeight;");
		return vertscrollStatus;
	}

	/**
	 * Scroll to element using javascript.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.javascriptScrollIntoWebelementView(_browser.webDriver, contactInfoLink);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The element to which scroll is needed
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void javascriptScrollIntoWebelementView(WebDriver driver, WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element);
	}

	/**
	 * Scroll to element using javascript.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.javascriptScrollIntoWebelementView(_browser.webDriver, contactInfoLink);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The supplier of the element to which scroll is needed
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void javascriptScrollIntoWebelementView(WebDriver driver, Supplier<WebElement> element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element.get());
	}

	/**
	 * Scroll to the top of the page.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.scrollToTop(_browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void scrollToTop(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(document.body.scrollLeft, 0)");
	}

	/**
	 * Scrolls to the bottom of the page.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.scrollToBottom(_browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void scrollToBottom(WebDriver driver) {
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		js1.executeScript("window.scrollTo(document.body.scrollLeft, document.body.scrollHeight)");
	}

	/**
	 * Scrolls to the bottom of the page.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.scrollToBottom(_browser.webDriver, 500);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * @param y      : y co-ordinate value to scroll down
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void scrollToBottom(WebDriver driver, int y) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(document.body.scrollLeft, " + y + ")");
	}

	/**
	 * Scrolls to the left end of the page.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.scrollToLeft(_browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void scrollToLeft(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0, document.body.scrollTop)");
	}

	/**
	 * Scrolls to the right end of the page
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.scrollToRight(_browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void scrollToRight(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(document.body.scrollWidth, document.body.scrollTop)");
	}

	/**
	 * Scrolls to the right end of the page
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.scrollToRight(_browser.webDriver, 200);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * @param x      : x coordinate value to scroll right
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void scrollToRight(WebDriver driver, int x) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(" + x + ", document.body.scrollTop)");
	}

	/**
	 * Open url.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.openUrl(_browser.webDriver, "https://www.google.com/");
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * @param url    : Url for navigation
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void openUrl(WebDriver driver, String url) {
		driver.navigate().to(url);
	}

	/**
	 * Get the current url.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.getCurrentUrl(_browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * @return current url
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static String getCurrentUrl(WebDriver driver) {
		String url = driver.getCurrentUrl();
		return url;
	}

	/**
	 * Navigate to back
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.navigateToBack(_browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void navigateToBack(WebDriver driver) {
		driver.navigate().back();
	}

	/**
	 * Click element using javascript executor.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.javascriptClick(_browser.webDriver, LoginButton);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The element to be clicked
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void javascriptClick(WebDriver driver, WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", element);
	}

	/**
	 * Click element using javascript executor.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.javascriptClick(_browser.webDriver, LoginButton);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The supplier of the element to be clicked
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void javascriptClick(WebDriver driver, Supplier<WebElement> element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", element.get());
	}

	/**
	 * Clear text using javascript executor.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.clearTextUsingJavascriptExecutor(_browser.webDriver, LoginUsernameTextbox);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The element to be cleared
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void clearTextUsingJavascriptExecutor(WebDriver driver, WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].value = '';", element);
	}

	/**
	 * Clear text using javascript executor.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.clearTextUsingJavascriptExecutor(_browser.webDriver, LoginUsernameTextbox);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The supplier of the element to be cleared
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void clearTextUsingJavascriptExecutor(WebDriver driver, Supplier<WebElement> element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].value = '';", element.get());
	}

	/**
	 * Clear text using backspace.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.clearTextUsingBackSpace(_browser.webDriver, LoginUsernameTextbox, 10);
	 * }
	 * </pre>
	 * 
	 * @param driver             : The current WebDriver instance
	 * @param element            : The element to be cleared
	 * @param numberOfCharacters : Number of backspace needed
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void clearTextUsingBackSpace(WebDriver driver, WebElement element, int numberOfCharacters) {
		for (int count = 1; count <= numberOfCharacters; count++) {
			element.sendKeys(Keys.BACK_SPACE);
		}
	}

	/**
	 * Clear text using backspace.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.clearTextUsingBackSpace(_browser.webDriver, LoginUsernameTextbox, 10);
	 * }
	 * </pre>
	 * 
	 * @param driver             : The current WebDriver instance
	 * @param element            : The supplier of the element to be cleared
	 * @param numberOfCharacters : Number of backspace needed
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void clearTextUsingBackSpace(WebDriver driver, Supplier<WebElement> element, int numberOfCharacters) {
		for (int count = 1; count <= numberOfCharacters; count++) {
			element.get().sendKeys(Keys.BACK_SPACE);
		}
	}

	/**
	 * Focus an element using java script executor.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.setFocusOnAnElement(_browser.webDriver, LoginUsernameTextbox);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The element to be focused
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void setFocusOnAnElement(WebDriver driver, WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].focus();", element);
	}

	/**
	 * Focus an element using java script executor.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.setFocusOnAnElement(_browser.webDriver, LoginUsernameTextbox);
	 * }
	 * </pre>
	 * 
	 * @param driver  : The current WebDriver instance
	 * @param element : The supplier of the element to be focused
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void setFocusOnAnElement(WebDriver driver, Supplier<WebElement> element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].focus();", element.get());
	}

	/**
	 * Switch to the last window
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * 
	 * WebDriverExtensions.switchToLastWindow(_browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void switchToLastWindow(WebDriver driver) {
		ArrayList<String> windowHandles = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(windowHandles.get(windowHandles.size() - 1));
	}

	/**
	 * Switch to window
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * 
	 * WebDriverExtensions.switchToWindow(_browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param driver           : The current WebDriver instance
	 * @param windowHandleName : Window handle name of the required window
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void switchToWindow(WebDriver driver, String windowHandleName) {
		driver.switchTo().window(windowHandleName);
	}

	/**
	 * Close the current window
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * 
	 * WebDriverExtensions.closeCurrentWindow(_browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void closeCurrentWindow(WebDriver driver) {
		driver.close();
	}

	/**
	 * Refresh current page
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * 
	 * WebDriverExtensions.pageRefresh(_browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void pageRefresh(WebDriver driver) {
		driver.navigate().refresh();
	}

	/**
	 * Generate locator
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.generateLocator(_browser.webDriver, _locatorForReplacerButton, "SignUp",
	 * 		Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver         : The current WebDriver instance
	 * @param dynamicLocator : The string locator value containing 'replacer' part
	 * @param replaceValue   : The dynamic value which will replace the 'replacer'
	 * @param locatorType    : The locator type enum value for locating the element
	 * @return Web element generated using specified locator type
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static WebElement generateLocator(WebDriver driver, String dynamicLocator, String replaceValue,
			Enum<?> locateType) {
		return locateElement(driver, dynamicLocator.replace("replacer", replaceValue), locateType);
	}

	/**
	 * Generate locator
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.generateLocator(_browser.webDriver, _locatorForReplacerButton, "SignUp",
	 * 		Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver         : The current WebDriver instance
	 * @param dynamicLocator : The supplier of the string locator value containing
	 *                       'replacer' part
	 * @param replaceValue   : The dynamic value which will replace the 'replacer'
	 * @param locatorType    : The locator type enum value for locating the element
	 * @return Web element generated using specified locator type
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static WebElement generateLocator(WebDriver driver, Supplier<String> dynamicLocator, String replaceValue,
			Enum<?> locateType) {
		return locateElement(driver, dynamicLocator.get().replace("replacer", replaceValue), locateType);
	}

	/**
	 * Generate locator
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * String _locatorForReplacerButton = "//replacer1[@type="replacer2"]";
	 * WebDriverExtensions.generateLocator(_browser.webDriver, _locatorWithReplacers, valuesToReplace,
	 * 		Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver         : The current WebDriver instance
	 * @param dynamicLocator : The string locator value containing multiple
	 *                       replacer(n) parts
	 * @param replaceValue   : The List of dynamic value which will replace the
	 *                       'replacer(n)'
	 * @param locatorType    : The locator type enum value for locating the element
	 * @return Web element generated using specified locator type
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static WebElement generateLocator(WebDriver driver, String dynamicLocator, List<String> replaceValue,
			Enum<?> locateType) {
		for (int i = 1; i <= replaceValue.size(); i++) {
			dynamicLocator = dynamicLocator.replace("replacer" + i, replaceValue.get(i - 1));
		}

		return locateElement(driver, dynamicLocator, locateType);
	}

	/**
	 * Generate locator
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Supplier<String> _locatorWithReplacers = () -> "//replacer1[@type="replacer2"]";
	 * WebDriverExtensions.generateLocator(_browser.webDriver, _locatorWithReplacers, valuesToReplace,
	 * 		Locator.LocatorType.Xpath);
	 * }
	 * </pre>
	 * 
	 * @param driver         : The current WebDriver instance
	 * @param dynamicLocator : The supplier of the string locator value containing
	 *                       multiple replacer(n) parts
	 * @param replaceValue   : The List of dynamic value which will replace the
	 *                       'replacer(n)'
	 * @param locatorType    : The locator type enum value for locating the element
	 * @return Web element generated using specified locator type
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static WebElement generateLocator(WebDriver driver, Supplier<String> dynamicLocator,
			List<String> replaceValue, Enum<?> locateType) {
		String newLocator = dynamicLocator.get();
		for (int i = 1; i <= replaceValue.size(); i++) {
			newLocator = newLocator.replace("replacer" + i, replaceValue.get(i - 1));
		}
		return locateElement(driver, newLocator, locateType);
	}

	/**
	 * Generate locators into list
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.generateLocatorsIntoList(_browser.webDriver, _locatorWithReplacer, "SignUp");
	 * }
	 * </pre>
	 * 
	 * @param driver         : The current WebDriver instance
	 * @param dynamicLocator : The string locator value containing replacer part
	 * @param replaceValue   : The dynamic value which will replace the 'replacer'
	 * @return List of generate locator
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static List<WebElement> generateLocatorsIntoList(WebDriver driver, String dynamicLocator,
			String replaceValue) {
		return getAllElementsIntoList(driver, dynamicLocator.replace("replacer", replaceValue));
	}

	/**
	 * Generate locators into list
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.generateLocatorsIntoList(_browser.webDriver, _locatorWithReplacer, "SignUp");
	 * }
	 * </pre>
	 * 
	 * @param driver         : The current WebDriver instance
	 * @param dynamicLocator : The supplier of the string locator value containing
	 *                       replacer part
	 * @param replaceValue   : The dynamic value which will replace the 'replacer'
	 * @return List of generate locator
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static List<WebElement> generateLocatorsIntoList(WebDriver driver, Supplier<String> dynamicLocator,
			String replaceValue) {
		return getAllElementsIntoList(driver, dynamicLocator.get().replace("replacer", replaceValue));
	}

	/**
	 * Confirms the alert pop up.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.confirmtAlert(_browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void confirmtAlert(WebDriver driver) {
		driver.switchTo().alert().accept();
		driver.switchTo().defaultContent();
	}

	/**
	 * Dismisses the alert pop up.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.dismissAlert(_browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void dismissAlert(WebDriver driver) {
		driver.switchTo().alert().dismiss();
		driver.switchTo().defaultContent();
	}

	/**
	 * Find element using relative locator.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.locateElementWithRelativeLocator(_browser.webDriver, By.tagName("input"), SignInButton,
	 * 		Locator.RelativeLocatorType.Above);
	 * }
	 * </pre>
	 * 
	 * @param driver              : The current WebDriver instance
	 * @param locator             : Locator of the element to be located
	 * @param nearByElement       : The element near to the required element
	 * @param relativeLocatorType : The relative locator enum value
	 * @return Required web element
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static WebElement locateElementWithRelativeLocator(WebDriver driver, By locator, WebElement nearByElement,
			Enum<?> relativeLocatorType) {
		WebElement element = null;
		if (relativeLocatorType.equals(Locator.RelativeLocatorType.Above)) {
			element = driver.findElement(with(locator).above(nearByElement));
		} else if (relativeLocatorType.equals(Locator.RelativeLocatorType.Below)) {
			element = driver.findElement(with(locator).below(nearByElement));
		} else if (relativeLocatorType.equals(Locator.RelativeLocatorType.RightOf)) {
			element = driver.findElement(with(locator).toRightOf(nearByElement));
		} else if (relativeLocatorType.equals(Locator.RelativeLocatorType.LeftOf)) {
			element = driver.findElement(with(locator).toLeftOf(nearByElement));
		} else {
			throw new NoSuchElementException();
		}
		return element;
	}

	/**
	 * Find element using relative locator.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.locateElementWithRelativeLocator(_browser.webDriver, "input", SignInButton,
	 * 		Locator.RelativeLocatorType.Above);
	 * }
	 * </pre>
	 * 
	 * @param driver              : The current WebDriver instance
	 * @param tagName             : Tag name of the element to be located
	 * @param nearByElement       : The element near to the required element
	 * @param relativeLocatorType : The relative locator enum value
	 * @return Required web element
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static WebElement locateElementWithRelativeLocator(WebDriver driver, String tagName,
			WebElement nearByElement, Enum<?> relativeLocatorType) {
		WebElement element = null;
		if (relativeLocatorType.equals(Locator.RelativeLocatorType.Above)) {
			element = driver.findElement(with(By.tagName(tagName)).above(nearByElement));
		} else if (relativeLocatorType.equals(Locator.RelativeLocatorType.Below)) {
			element = driver.findElement(with(By.tagName(tagName)).below(nearByElement));
		} else if (relativeLocatorType.equals(Locator.RelativeLocatorType.RightOf)) {
			element = driver.findElement(with(By.tagName(tagName)).toRightOf(nearByElement));
		} else if (relativeLocatorType.equals(Locator.RelativeLocatorType.LeftOf)) {
			element = driver.findElement(with(By.tagName(tagName)).toLeftOf(nearByElement));
		} else {
			throw new NoSuchElementException();
		}
		return element;
	}

	/**
	 * Locate the element with above and below elements
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.locateElementWithAboveAndBelowLocators(_browser.webDriver, By.tagName("input"), SignInButton,
	 * 		LoginUsernameTextbox);
	 * }
	 * </pre>
	 * 
	 * @param driver             : The current WebDriver instance
	 * @param locator            : Locator of the element to be located
	 * @param nearByElementBelow : The element above the required element
	 * @param nearByElementAbove : The element below the required element
	 * @return Required web element
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static WebElement locateElementWithAboveAndBelowLocators(WebDriver driver, By locator,
			WebElement nearByElementBelow, WebElement nearByElementAbove) {
		return driver.findElement(with(locator).below(nearByElementBelow).above(nearByElementAbove));
	}

	/**
	 * Locate the element with above and below elements
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.locateElementWithAboveAndBelowLocators(_browser.webDriver, "input", SignInButton,
	 * 		LoginUsernameTextbox);
	 * }
	 * </pre>
	 * 
	 * @param driver             : The current WebDriver instance
	 * @param tagName            : Tag name of the element to be located
	 * @param nearByElementBelow : The element above the required element
	 * @param nearByElementAbove : The element below the required element
	 * @return Required web element
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static WebElement locateElementWithAboveAndBelowLocators(WebDriver driver, String tagName,
			WebElement nearByElementBelow, WebElement nearByElementAbove) {
		return driver.findElement(with(By.tagName(tagName)).below(nearByElementBelow).above(nearByElementAbove));
	}

	/**
	 * Clear the browser data
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebDriverExtensions.clearBrowserData(_browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param driver : The current WebDriver instance
	 * 
	 * @author PACE Team
	 * @version 2.1.0
	 * @since 2024-08-08
	 */
	public static void clearBrowserData(WebDriver driver) {
		driver.manage().deleteAllCookies();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.localStorage.clear();");
		js.executeScript("window.sessionStorage.clear();");
		js.executeScript("window.location.reload();");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}