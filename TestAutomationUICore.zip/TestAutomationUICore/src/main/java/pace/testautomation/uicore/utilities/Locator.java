package pace.testautomation.uicore.utilities;

public class Locator {
	
	static {
		UiFrameworkSupport.FrameworkExpiryDateCheckWithoutWarning();
	}
	
	/**
	 * Enumerators for locator types.
	 *
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static enum LocatorType {
		Id, Xpath, Name, CssSelector, ClassName, LinkText, PartialLinkText, TagName,
	}

	/**
	 * Enumerators for relative locator types.
	 *
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static enum RelativeLocatorType {
		Above, Below, Near, RightOf, LeftOf, AboveAndBelow,
	}
}