package pace.testautomation.uicore.utilities;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.Arrays;
import java.util.Comparator;

public class RobotScreenRecorder {

	private static Robot robot;

	static {
		try {
			robot = new Robot();
		} catch (Exception exp) {
			exp.printStackTrace();
		}
	}

	/**
	 * Start screen record using windows xbox screen recorder
	 * 
	 * @throws InterruptedException
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void startRecord() throws InterruptedException {
		robot.keyPress(KeyEvent.VK_WINDOWS);
		robot.keyPress(KeyEvent.VK_ALT);
		robot.keyPress(KeyEvent.VK_R);
		Thread.sleep(500);
		robot.keyRelease(KeyEvent.VK_R);
		robot.keyRelease(KeyEvent.VK_ALT);
		robot.keyRelease(KeyEvent.VK_WINDOWS);
	}

	/**
	 * Stop screen record using windows xbox screen recorder
	 * 
	 * @throws InterruptedException
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void stopRecord() throws InterruptedException {
		robot.keyPress(KeyEvent.VK_WINDOWS);
		robot.keyPress(KeyEvent.VK_ALT);
		robot.keyPress(KeyEvent.VK_R);
		Thread.sleep(500);
		robot.keyRelease(KeyEvent.VK_R);
		robot.keyRelease(KeyEvent.VK_ALT);
		robot.keyRelease(KeyEvent.VK_WINDOWS);
	}

	/**
	 * Delete the recorded file
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void deleteRecording() {

		String folderPath = "./recordings/Captures";

		File folder = new File(folderPath);

		if (folder.exists() && folder.isDirectory()) {
			File[] files = folder.listFiles();
			Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());

			if (files.length > 0) {
				File newestFile = files[0];

				if (newestFile.delete()) {
					System.out.println("Deleted the newest file: " + newestFile.getName());
				} else {
					System.err.println("Failed to delete the newest file: " + newestFile.getName());
				}
			} else {
				System.out.println("No files found in the folder.");
			}
		} else {
			System.err.println("The specified path is not a valid folder.");
		}
	}
}
