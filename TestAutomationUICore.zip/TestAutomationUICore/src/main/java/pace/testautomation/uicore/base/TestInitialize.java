package pace.testautomation.uicore.base;

import java.net.URI;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.RemoteWebDriver;

import pace.testautomation.uicore.utilities.UiFrameworkSupport;

/**
 * TestInitialize class which has to be extended to the required TestClass.
 * 
 * @author PACE Team
 * @version 1.0.0
 * @since 2023-03-01
 */
public class TestInitialize extends TestBase {

	/**
	 * Test initialize
	 * 
	 * This class has to be extended to the required TestClass.
	 * 
	 * @author Pace Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public TestInitialize() {
		UiFrameworkSupport.FrameworkExpiryDateCheck();
	}

	/**
	 * Test Fixture initialization.
	 * 
	 * After extending TestInitialize to the required TestClass , this method needs
	 * to be called as the @BeforeClass method to initialize the driver based on the
	 * settings provided in the System Properties
	 * 
	 * @author Pace Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public void testFixtureSetUp() throws Exception {
		this.chooseBrowser();
	}

	/**
	 * Test Fixture closure.
	 * 
	 * After extending TestInitialize to the required TestClass , this method needs
	 * to be called as the @AfterClass method to quit the running driver instance
	 * 
	 * @author Pace Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public void testFixtureTearDown() {
		this._browser.webDriver.quit();
	}

	/**
	 * Navigation to the application.
	 * 
	 * After extending TestInitialize to the required TestClass , this method needs
	 * to be called as the @BeforeMethod method to navigate to the base url
	 * specified in the System Properties
	 * 
	 * @author Pace Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public void navigateToApplication() throws Exception {
		_browser.webDriver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(120));
		if (System.getProperty("server") == null)
			throw new Exception("The server url is not defined in the pom.xml file");
		_browser.webDriver.navigate().to(System.getProperty("server"));
		_browser.webDriver.manage().window().maximize();
	}

	/**
	 * Navigation to the application.
	 * 
	 * After extending TestInitialize to the required TestClass , this method needs
	 * to be called as the @BeforeMethod method to navigate to the url specified in
	 * the parameter
	 * 
	 * @param url - Server url.
	 * 
	 * @author Pace Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public void navigateToApplication(String url) {
		_browser.webDriver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(120));
		_browser.webDriver.navigate().to(url);
		_browser.webDriver.manage().window().maximize();
	}

	/**
	 * Get hub url.
	 * 
	 * @param hub
	 * @return required hub url
	 * 
	 * @author Pace Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	private String getHubUrl(String hub) throws Exception {
		String hubUrl = (hub.equals("remoteHub")) ? System.getProperty("remoteHubUrl")
				: (hub.equals("grid")) ? System.getProperty("seleniumGridUrl") : System.getProperty("zaleniumHubUrl");
		if (hubUrl == null)
			throw new Exception("The hub url for " + hub + " is not defined in the pom.xml file");
		return hubUrl;
	}

	/**
	 * Choosing browser.
	 * 
	 * @example extends TestInitialize : ChooseBrowser() - This method will invoke
	 *          the instance based on the hub
	 * @author Pace Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	private void chooseBrowser() throws Exception {
		String hub;
		if (System.getProperty("hub") != null)
			hub = System.getProperty("hub");
		else
			throw new Exception("Property hub is not defined in the pom.xml file");

		String browserName;
		if (System.getProperty("browser") != null)
			browserName = System.getProperty("browser");
		else
			throw new Exception("Property browser is not defined in the pom.xml file");

		Boolean runHeadless = System.getProperty("runHeadless") != null
				&& Boolean.parseBoolean(System.getProperty("runHeadless"));
		Boolean autoFillCardDetails = System.getProperty("autoFillCardDetails") != null
				&& Boolean.parseBoolean(System.getProperty("autoFillCardDetails"));
		Map<Object, Object> browserOptions = BrowserOptions.additionalCapabilities(hub, browserName);
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("autofill.credit_card_enabled", autoFillCardDetails);

		if (hub.equals("localHub")) {
			if (browserName.equals("chrome")) {
				ChromeOptions chromeOptions = new ChromeOptions();
				if (runHeadless)
					chromeOptions.addArguments("--headless");
				chromeOptions.addArguments("--remote-allow-origins=*");
				chromeOptions.setExperimentalOption("prefs", prefs);
				this._browser.webDriver = new ChromeDriver(chromeOptions);
			} else if (browserName.equals("firefox")) {
				FirefoxOptions firefoxOptions = new FirefoxOptions();
				if (runHeadless)
					firefoxOptions.addArguments("--headless");
				firefoxOptions.addArguments("--remote-allow-origins=*");
				this._browser.webDriver = new FirefoxDriver();
			}
		} else if (hub.equals("remoteHub")) {
			if (browserName.equals("chrome")) {
				ChromeOptions chromeOptions = new ChromeOptions();
				if (runHeadless)
					chromeOptions.addArguments("--headless");
				chromeOptions.setExperimentalOption("prefs", prefs);
				this._browser.webDriver = new RemoteWebDriver(URI.create(getHubUrl(hub)).toURL(), chromeOptions);
			} else if (browserName.equals("firefox")) {
				FirefoxOptions firefoxOptions = new FirefoxOptions();
				if (runHeadless)
					firefoxOptions.addArguments("--headless");
				this._browser.webDriver = new RemoteWebDriver(URI.create(getHubUrl(hub)).toURL(), firefoxOptions);
			}

		} else if (hub.equals("grid")) {
			ChromeOptions chromeOptions = new ChromeOptions();
			if (runHeadless)
				chromeOptions.addArguments("--headless");
			chromeOptions.addArguments(browserOptions.toString());
			chromeOptions.setExperimentalOption("prefs", prefs);
			this._browser.webDriver = new RemoteWebDriver(URI.create(getHubUrl(hub)).toURL(), chromeOptions);
		}
	}
}