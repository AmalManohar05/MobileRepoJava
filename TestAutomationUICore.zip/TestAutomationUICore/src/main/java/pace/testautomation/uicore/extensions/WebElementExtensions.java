package pace.testautomation.uicore.extensions;

import java.util.List;
import java.util.function.Supplier;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import pace.testautomation.uicore.utilities.UiFrameworkSupport;

/**
 * WebElementExtensions class containing wrapper methods for the web elements
 * 
 * @author PACE Team
 * @version 1.0.0
 * @since 2023-03-01
 */
public class WebElementExtensions {

	static {
		UiFrameworkSupport.FrameworkExpiryDateCheckWithoutWarning();
	}

	/**
	 * Check whether the element is present or not.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.isElementPresent(SignInButton);
	 * }
	 * </pre>
	 * 
	 * @param element : The element who's presence is being checked
	 * @return Whether the element is present or not (true/false)
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static boolean isElementPresent(WebElement element) {
		if (element.isDisplayed()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Check whether the element is present or not.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.isElementPresent(SignInButton);
	 * }
	 * </pre>
	 * 
	 * @param element : The supplier for the element who's presence is being checked
	 * @return Whether the element is present or not (true/false)
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static boolean isElementPresent(Supplier<WebElement> element) {
		if (element.get().isDisplayed()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Getting the selected value in a drop down.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.getSelectedDropDown(CountryListDropDown);
	 * }
	 * </pre>
	 * 
	 * @param element : The element for the drop down
	 * @return Selected option of drop down
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static String getSelectedDropDown(WebElement element) {
		Select ddl = new Select(element);
		return ddl.getFirstSelectedOption().getText();
	}

	/**
	 * Getting the selected value in a drop down.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.getSelectedDropDown(CountryListDropDown);
	 * }
	 * </pre>
	 * 
	 * @param element : The supplier of the element for the drop down
	 * @return Selected option of drop down
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static String getSelectedDropDown(Supplier<WebElement> element) {
		Select ddl = new Select(element.get());
		return ddl.getFirstSelectedOption().getText();
	}

	/**
	 * Getting the selected list of values from a drop down.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.getSelectedListOptions(CountryListDropDown);
	 * }
	 * </pre>
	 * 
	 * @param element :The element for the drop down
	 * @return Selected list of option from drop down
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static List<WebElement> getSelectedListOptions(WebElement element) {
		Select ddl = new Select(element);
		return ddl.getAllSelectedOptions();
	}

	/**
	 * Getting the selected list of values from a drop down.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.getSelectedListOptions(CountryListDropDown);
	 * }
	 * </pre>
	 * 
	 * @param element :The supplier of the element for the drop down
	 * @return Selected list of option from drop down
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static List<WebElement> getSelectedListOptions(Supplier<WebElement> element) {
		Select ddl = new Select(element.get());
		return ddl.getAllSelectedOptions();
	}

	/**
	 * Select an option from drop down by value.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.selectDropDownListByValue(CountryListDropDown, "India");
	 * }
	 * </pre>
	 * 
	 * @param element : The element for the drop down
	 * @param value   : The value for the list option
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void selectDropDownListByValue(WebElement element, String value) {
		Select ddl = new Select(element);
		ddl.selectByValue(value);
	}

	/**
	 * Select an option from drop down by value.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.selectDropDownListByValue(CountryListDropDown, "India");
	 * }
	 * </pre>
	 * 
	 * @param element : The supplier of the element for the drop down
	 * @param value   : The value for the list option
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void selectDropDownListByValue(Supplier<WebElement> element, String value) {
		Select ddl = new Select(element.get());
		ddl.selectByValue(value);
	}

	/**
	 * Getting text from an element.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.getElementText(DashboardHeader);
	 * }
	 * </pre>
	 * 
	 * @param element : The element who's text is being fetched
	 * @return Element text
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static String getElementText(WebElement element) {
		return element.getText();
	}

	/**
	 * Getting text from an element.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.getElementText(DashboardHeader);
	 * }
	 * </pre>
	 * 
	 * @param element : The supplier of the element who's text is being fetched
	 * @return Element text
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static String getElementText(Supplier<WebElement> element) {
		return element.get().getText();
	}

	/**
	 * Getting attribute value from an element.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.getElementAttribute(LoginUsernameTextbox, "placeholder");
	 * }
	 * </pre>
	 * 
	 * @param element : The element who's attribute value is being fetched
	 * @param value   : The required attribute name
	 * @return Element attribute value
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static String getElementAttribute(WebElement element, String value) {
		return element.getAttribute(value);
	}

	/**
	 * Getting attribute value from an element.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.getElementAttribute(LoginUsernameTextbox, "placeholder");
	 * }
	 * </pre>
	 * 
	 * @param element : The supplier of the element who's attribute value is being
	 *                fetched
	 * @param value   : The required attribute name
	 * @return Element attribute value
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static String getElementAttribute(Supplier<WebElement> element, String value) {
		return element.get().getAttribute(value);
	}

	/**
	 * Select an option from drop down by text.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.selectDropDownListByText(CountryDropDownList, "INDIA");
	 * }
	 * </pre>
	 * 
	 * @param element : The element of the drop down
	 * @param text    : The text of the option
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void selectDropDownListByText(WebElement element, String text) {
		Select ddl = new Select(element);
		ddl.selectByVisibleText(text);
	}

	/**
	 * Select an option from drop down by text.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.selectDropDownListByText(CountryDropDownList, "INDIA");
	 * }
	 * </pre>
	 * 
	 * @param element : The supplier of the element of the drop down
	 * @param text    : The text of the option
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void selectDropDownListByText(Supplier<WebElement> element, String text) {
		Select ddl = new Select(element.get());
		ddl.selectByVisibleText(text);
	}

	/**
	 * Select an option from drop down by index.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.selectDropDownListByIndex(CountryDropDownList, 1);
	 * }
	 * </pre>
	 * 
	 * @param element : The element of the drop down
	 * @param index   : The index of required option
	 * 
	 * @author PACE Team
	 * @version 2.1.1
	 * @since 2024-08-10
	 */
	public static void selectDropDownListByIndex(WebElement element, int index) {
		Select ddl = new Select(element);
		ddl.selectByIndex(index);
	}

	/**
	 * Select an option from drop down by index.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.selectDropDownListByIndex(CountryDropDownList, 1);
	 * }
	 * </pre>
	 * 
	 * @param element : The supplier of the element of the drop down
	 * @param index   : The index of required option
	 * 
	 * @author PACE Team
	 * @version 2.1.1
	 * @since 2024-08-10
	 */
	public static void selectDropDownListByIndex(Supplier<WebElement> element, int index) {
		Select ddl = new Select(element.get());
		ddl.selectByIndex(index);
	}

	/**
	 * Click on the given element.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.click(AddButton);
	 * }
	 * </pre>
	 * 
	 * @param element : The supplier of the element to be clicked
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void click(Supplier<WebElement> element) {
		element.get().click();
	}

	/**
	 * Click on the given element.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.click(AddButton);
	 * }
	 * </pre>
	 * 
	 * @param element : The element to be clicked
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void click(WebElement element) {
		element.click();
	}

	/**
	 * Send text to the element.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.sendKeys(LoginUsernameTextbox, "user@test.in");
	 * }
	 * </pre>
	 * 
	 * @param element : The supplier of the element to which text is sent
	 * @param text    : The text to be sent
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void sendKeys(Supplier<WebElement> element, String text) {
		element.get().sendKeys(text);
	}

	/**
	 * Send text to the element.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.sendKeys(LoginUsernameTextbox, "user@test.in");
	 * }
	 * </pre>
	 * 
	 * @param element : The element to which text is sent
	 * @param text    : The text to be sent
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void sendKeys(WebElement element, String text) {
		element.sendKeys(text);
	}

	/**
	 * Clear the text value in the element.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.clearText(LoginUsernameTextbox);
	 * }
	 * </pre>
	 * 
	 * @param element : The supplier of the element to be cleared
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void clearText(Supplier<WebElement> element) {
		element.get().clear();
	}

	/**
	 * Clear the text value in the element.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.clearText(LoginUsernameTextbox);
	 * }
	 * </pre>
	 * 
	 * @param element : The element to be cleared
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void clearText(WebElement element) {
		element.clear();
	}

	/**
	 * Clear text using backspace.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.clearInputTextUsingBackSpace(LoginUsernameTextbox);
	 * }
	 * </pre>
	 * 
	 * @param element : The element to be cleared
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void clearInputTextUsingBackSpace(WebElement element) {
		int numberOfCharacters = element.getAttribute("value").length();
		for (int count = 1; count <= numberOfCharacters; count++) {
			element.sendKeys(Keys.BACK_SPACE);
		}
	}

	/**
	 * Clear text using backspace.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.clearInputTextUsingBackSpace(LoginUsernameTextbox);
	 * }
	 * </pre>
	 * 
	 * @param element : The supplier of the element to be cleared
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void clearInputTextUsingBackSpace(Supplier<WebElement> element) {
		int numberOfCharacters = element.get().getAttribute("value").length();
		for (int count = 1; count <= numberOfCharacters; count++) {
			element.get().sendKeys(Keys.BACK_SPACE);
		}
	}

	/**
	 * De-select all options from drop down.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.deselectAllDropDownOptions(CountryDropDownList);
	 * }
	 * </pre>
	 * 
	 * @param element : The element of the drop down
	 * 
	 * @author PACE Team
	 * @version 2.1.1
	 * @since 2024-08-10
	 */
	public static void deselectAllDropDownOptions(WebElement element) {
		Select ddl = new Select(element);
		ddl.deselectAll();
	}

	/**
	 * De-select all options from drop down.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.deselectAllDropDownOptions(CountryDropDownList);
	 * }
	 * </pre>
	 * 
	 * @param element : The supplier of the element of the drop down
	 * 
	 * @author PACE Team
	 * @version 2.1.1
	 * @since 2024-08-10
	 */
	public static void deselectAllDropDownOptions(Supplier<WebElement> element) {
		Select ddl = new Select(element.get());
		ddl.deselectAll();
	}

	/**
	 * De-select an option from drop down by index.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.deselectDropDownOptionByIndex(CountryDropDownList, 1);
	 * }
	 * </pre>
	 * 
	 * @param element : The element of the drop down
	 * @param index   : The index of required option
	 * 
	 * @author PACE Team
	 * @version 2.1.1
	 * @since 2024-08-10
	 */
	public static void deselectDropDownOptionByIndex(WebElement element, int index) {
		Select ddl = new Select(element);
		ddl.deselectByIndex(index);
	}

	/**
	 * De-select an option from drop down by index.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.deselectDropDownOptionByIndex(CountryDropDownList, 1);
	 * }
	 * </pre>
	 * 
	 * @param element : The supplier of the element of the drop down
	 * @param index   : The index of required option
	 * 
	 * @author PACE Team
	 * @version 2.1.1
	 * @since 2024-08-10
	 */
	public static void deselectDropDownOptionByIndex(Supplier<WebElement> element, int index) {
		Select ddl = new Select(element.get());
		ddl.deselectByIndex(index);
	}

	/**
	 * De-select an option from drop down by value.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.deselectDropDownOptionByValue(CountryDropDownList, "USA");
	 * }
	 * </pre>
	 * 
	 * @param element : The element of the drop down
	 * @param value   : The value of required option
	 * 
	 * @author PACE Team
	 * @version 2.1.1
	 * @since 2024-08-10
	 */
	public static void deselectDropDownOptionByValue(WebElement element, String value) {
		Select ddl = new Select(element);
		ddl.deselectByValue(value);
	}

	/**
	 * De-select an option from drop down by value.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.deselectDropDownOptionByValue(CountryDropDownList, "USA");
	 * }
	 * </pre>
	 * 
	 * @param element : The supplier of the element of the drop down
	 * @param value   : The value of required option
	 * 
	 * @author PACE Team
	 * @version 2.1.1
	 * @since 2024-08-10
	 */
	public static void deselectDropDownOptionByValue(Supplier<WebElement> element, String value) {
		Select ddl = new Select(element.get());
		ddl.deselectByValue(value);
	}

	/**
	 * De-select an option from drop down by text.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.deselectDropDownOptionByText(CountryDropDownList, "USA");
	 * }
	 * </pre>
	 * 
	 * @param element : The element of the drop down
	 * @param text    : The text of required option
	 * 
	 * @author PACE Team
	 * @version 2.1.1
	 * @since 2024-08-10
	 */
	public static void deselectDropDownOptionByText(WebElement element, String text) {
		Select ddl = new Select(element);
		ddl.deselectByVisibleText(text);
	}

	/**
	 * De-select an option from drop down by text.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * WebElementExtensions.deselectDropDownOptionByText(CountryDropDownList, "USA");
	 * }
	 * </pre>
	 * 
	 * @param element : The supplier of the element of the drop down
	 * @param text    : The text of required option
	 * 
	 * @author PACE Team
	 * @version 2.1.1
	 * @since 2024-08-10
	 */
	public static void deselectDropDownOptionByText(Supplier<WebElement> element, String text) {
		Select ddl = new Select(element.get());
		ddl.deselectByVisibleText(text);
	}
}