package pace.testautomation.uicore.base;

public class TestBase {
	/**
	 * Initialize the browser object
	 * 
	 * @author Pace Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public Browser _browser = new Browser();
}
