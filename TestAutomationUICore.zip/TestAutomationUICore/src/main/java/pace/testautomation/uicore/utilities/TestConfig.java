package pace.testautomation.uicore.utilities;

import org.testng.SkipException;

/**
 * TestConfig class to skip and continue test execution based on provided conditions
 * 
 * @author PACE Team
 * @version 1.0.0
 * @since 2023-03-01
 */
public class TestConfig {
	
	static {
		UiFrameworkSupport.FrameworkExpiryDateCheckWithoutWarning();
	}

	/**
	 * To ignore the test from further execution
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * TestConfig.testIgnore(abcdSwitchCondition, "Test can be skipped when ABCD switch
	 *          is true");
	 * }
	 * 
	 * TestConfig.testIgnore(!abcdSwitchCondition, "Test can be skipped when ABCD
	 *          switch is false");
	 * </pre>
	 * 
	 * @param condition : The condition determining whether or not the test should be ignored
	 * @param testIgnoreReason : The reason for ignoring the test
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void testIgnore(Boolean condition, String testIgnoreReason) {
		if (condition) {
			throw new SkipException(testIgnoreReason);
		}
	}

	/**
	 * To continue the test for further execution
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * TestConfig.testContinue(abcdSwitchCondition, "Test can be continued when ABCD switch
	 *          is true");
	 * }
	 * 
	 * TestConfig.testContinue(!abcdSwitchCondition, "Test can be continued when ABCD
	 *          switch is false");
	 * </pre>
	 * 
	 * @param condition : The condition determining whether or not the test should be continued
	 * @param testIgnoreReason : The reason for ignoring the test
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void testContinue(Boolean condition, String testContinueReason) {
		if (!condition) {
			throw new SkipException(testContinueReason);
		}
	}
}