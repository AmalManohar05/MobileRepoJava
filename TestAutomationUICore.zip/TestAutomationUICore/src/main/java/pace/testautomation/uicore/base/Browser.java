package pace.testautomation.uicore.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

public class Browser {

	/**
	 * Gets or sets the Web driver.
	 * 
	 * @author Pace Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public WebDriver webDriver;

	/**
	 * Gets or sets the Remote web driver.
	 * 
	 * @author Pace Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public RemoteWebDriver concurrentDriver;

	/**
	 * Get webdriver
	 * 
	 * @return WebDriver
	 * 
	 * @author Pace Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public WebDriver getWebDriver() {
		return webDriver;
	}

	/**
	 * Set webdriver
	 * 
	 * @return WebDriver
	 * 
	 * @author Pace Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public void setWebDriver(WebDriver webDriver) {
		this.webDriver = webDriver;
	}

	/**
	 * Get Remote webdriver
	 * 
	 * @return RemoteWebDriver
	 * 
	 * @author Pace Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public RemoteWebDriver getConcurrentDriver() {
		return concurrentDriver;
	}

	/**
	 * Set remote webdriver
	 * 
	 * @return WebDriver
	 * 
	 * @author Pace Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public void setConcurrentDriver(RemoteWebDriver concurrentDriver) {
		this.concurrentDriver = concurrentDriver;
	}

}
