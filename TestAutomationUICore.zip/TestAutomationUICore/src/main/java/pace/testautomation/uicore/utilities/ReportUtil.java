package pace.testautomation.uicore.utilities;

import java.io.ByteArrayInputStream;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import io.qameta.allure.Allure;
import io.qameta.allure.Attachment;

@Deprecated
public class ReportUtil {
	
	static {
		UiFrameworkSupport.FrameworkExpiryDateCheckWithoutWarning();
	}

	/**
	 * Take screenshot and return it as byte array
	 * @example ReportUtil.TakeScreenshot(WebDriver driver);
	 * @param driver
	 * @return Screenshots as byte input stream
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	@Attachment(value = "Screenshot", type = "image/png")
	public static ByteArrayInputStream TakeScreenshot(WebDriver driver) {
		return new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES));
	}

	/**
	 * Save the text log to attach
	 * @example ReportUtil.TakeScreenshot(String message);
	 * @param message
	 * @return text log
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	@Attachment(value = "{0}", type = "text/plain")
	public static String SaveTextLog(String message) {
		return message;
	}

	/**
	 * Add failure test attachment into the report
	 * @example ReportUtil.AddFailureTestAttachment(WebDriver driver);
	 * @param driver
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void AddFailureTestAttachment(WebDriver driver) {
		Allure.addAttachment("FailureTestAttachment", TakeScreenshot(driver));
	}

	/**
	 * Generate the allure report
	 * @example ReportUtil.AllureReportGeneration(ITestResult result, WebDriver driver);
	 * @param result
	 * @param driver
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void AllureReportGeneration(ITestResult result, WebDriver driver) {
		try {
			if (!(result.getStatus() == ITestResult.SUCCESS)) {
				AddFailureTestAttachment(driver);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}