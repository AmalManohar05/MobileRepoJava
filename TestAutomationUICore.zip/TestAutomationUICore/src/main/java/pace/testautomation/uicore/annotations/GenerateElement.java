package pace.testautomation.uicore.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Generate element annotation interface.
 * 
 * @author PACE Team
 * @version 1.0.0
 * @since 2023-03-01
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface GenerateElement {
	 String locatorType() default "xpath"; // Type of the locator (e.g., "xpath", "id", "name")
	 String locatorValue(); // Value of the locator (e.g., "//input[@id='username']", "myElementId")
}
