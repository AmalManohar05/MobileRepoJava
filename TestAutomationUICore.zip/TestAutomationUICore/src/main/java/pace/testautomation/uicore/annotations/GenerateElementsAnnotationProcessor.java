package pace.testautomation.uicore.annotations;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pace.testautomation.uicore.base.Browser;
import pace.testautomation.uicore.utilities.UiFrameworkSupport;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GenerateElementsAnnotationProcessor {
	
	static {
		UiFrameworkSupport.FrameworkExpiryDateCheckWithoutWarning();
	}

    private static Map<Method, Object> lazyLoadedElements = new HashMap<>();

    /**
     * Method which stores all the elements from the string fields in the page class
     * @param pageObject
     * @param browser
     * 
     * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
     */
    public static void processAnnotations(Object pageObject, Browser browser) {
        Class<?> clazz = pageObject.getClass();
        Field[] fields = clazz.getDeclaredFields();
        for (Field field : fields) {
            if (field.isAnnotationPresent(GenerateElement.class)) {
                field.setAccessible(true);
                Object proxyElement = createProxyObject(browser.webDriver, field.getType(), field.getAnnotation(GenerateElement.class).locatorType(), field.getAnnotation(GenerateElement.class).locatorValue());
                try {
                    field.set(pageObject, proxyElement);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            } else if (field.isAnnotationPresent(GenerateElementsIntoList.class)) {
                field.setAccessible(true);
                Object proxyElements = createProxyObject(browser.webDriver, field.getType(), field.getAnnotation(GenerateElementsIntoList.class).locatorType(), field.getAnnotation(GenerateElementsIntoList.class).locatorValue());
                try {
                    field.set(pageObject, proxyElements);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private static Object createProxyObject(WebDriver driver, Class<?> fieldType, String locatorType, String locatorValue) {
        InvocationHandler handler = new LazyInvocationHandler(driver, fieldType, locatorType, locatorValue);
        return Proxy.newProxyInstance(fieldType.getClassLoader(), new Class[]{fieldType}, handler);
    }

    private static class LazyInvocationHandler implements InvocationHandler {
        private final WebDriver driver;
        private final Class<?> fieldType;
        private final String locatorType;
        private final String locatorValue;
        private Object elements;

        public LazyInvocationHandler(WebDriver driver, Class<?> fieldType, String locatorType, String locatorValue) {
            this.driver = driver;
            this.fieldType = fieldType;
            this.locatorType = locatorType;
            this.locatorValue = locatorValue;
        }

        @Override
        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            if (elements == null) {
                if (List.class.isAssignableFrom(fieldType)) {
                    elements = driver.findElements(selectLocator(locatorType, locatorValue));
                } else {
                    elements = driver.findElement(selectLocator(locatorType, locatorValue));
                }
                lazyLoadedElements.put(method, elements);
            }

            return method.invoke(lazyLoadedElements.get(method), args);
        }
    }

    private static By selectLocator(String locatorType, String locatorValue) {
        
        switch (locatorType) {
            case "cssSelector":
                return By.cssSelector(locatorValue);
            case "xpath":
                return By.xpath(locatorValue);
            // Add support for other selector types as needed
            default:
                throw new IllegalArgumentException("Invalid selector type: " + locatorType);
        }
    }
}
