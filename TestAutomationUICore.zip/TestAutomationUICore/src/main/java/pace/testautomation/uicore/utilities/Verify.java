package pace.testautomation.uicore.utilities;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

/**
 * Verify class to execute assertions and still continue the test even if the
 * assertions fails.
 * 
 * @author PACE Team
 * @version 1.0.0
 * @since 2023-03-01
 */
public class Verify {

	static {
		UiFrameworkSupport.FrameworkExpiryDateCheckWithoutWarning();
	}

	/**
	 * The wrapper for Is True when case is true. When case is false, verification
	 * will be skipped.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Verify.isTrueWhenCaseIsTrue(switchCondition, expectedBool, _browser.webDriver,
	 * 		"Expected boolean was not true when switch condition was true");
	 * }
	 * </pre>
	 * 
	 * @param switchCondition : The decider whether or not the verification should
	 *                        be done
	 * @param expected        : The boolean value expected to be true
	 * @param driver          : The active WebDriver instance
	 * @param failureReason   : The reason to be logged with the failure
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void isTrueWhenCaseIsTrue(Boolean switchCondition, Boolean expected, WebDriver driver,
			String failureReason) {
		if (switchCondition) {
			try {
				Assert.assertTrue(expected, failureReason);
			} catch (AssertionError error) {
				ExtentReportHelpers.logTestAtVerify(error, failureReason, driver);
			}
		}
	}

	/**
	 * The wrapper for Is False when case is false. When case is true, verification
	 * will be skipped.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Verify.isFalseWhenCaseIsFalse(switchCondition, expectedBool, _browser.webDriver,
	 * 		"Expected boolean was not false when switch condition was false");
	 * }
	 * </pre>
	 * 
	 * @param switchCondition : The decider whether or not the verification should
	 *                        be done
	 * @param expected        : The boolean value expected to be false
	 * @param driver          : The active WebDriver instance
	 * @param failureReason   : The reason to be logged with the failure
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void isFalseWhenCaseIsFalse(Boolean switchCondition, Boolean expected, WebDriver driver,
			String failureReason) {
		if (!switchCondition) {
			try {
				Assert.assertFalse(expected, failureReason);
			} catch (AssertionError error) {
				ExtentReportHelpers.logTestAtVerify(error, failureReason, driver);
			}
		}
	}

	/**
	 * The wrapper for AreEqual when case is true. When case is false, verification
	 * will be skipped.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Verify.areEqualWhenCaseIsTrue(switchCondition, 15, actualNumber, _browser.webDriver,
	 * 		"Actual number was not equal to 15 when switch condition was true");
	 * }
	 * </pre>
	 * 
	 * @param switchCondition : The decider whether or not the verification should
	 *                        be done
	 * @param expected        : The expected value
	 * @param actual          : The actual value to be equal to the expected value
	 * @param driver          : The active WebDriver instance
	 * @param failureReason   : The reason to be logged with the failure
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void areEqualWhenCaseIsTrue(Boolean switchCondtion, Object expected, Object actual, WebDriver driver,
			String failureReason) {
		if (switchCondtion) {
			try {
				Assert.assertEquals(expected, actual, failureReason);
			} catch (AssertionError error) {
				ExtentReportHelpers.logTestAtVerify(error, failureReason, driver);
			}
		}
	}

	/**
	 * The wrapper for AreNotEqual when case is true. When case is false,
	 * verification will be skipped.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Verify.areNotEqualWhenCaseIsTrue(switchCondition, 15, actualNumber, _browser.webDriver,
	 * 		"Actual number was 15 when switch condition was true");
	 * }
	 * </pre>
	 * 
	 * @param switchCondition : The decider whether or not the verification should
	 *                        be done
	 * @param expected        : The expected value
	 * @param actual          : The actual value to be not equal to the expected
	 *                        value
	 * @param driver          : The active WebDriver instance
	 * @param failureReason   : The reason to be logged with the failure
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void areNotEqualWhenCaseIsTrue(Boolean switchCondtion, Object expected, Object actual,
			WebDriver driver, String failureReason) {
		if (switchCondtion) {
			try {
				Assert.assertNotEquals(expected, actual, failureReason);
			} catch (AssertionError error) {
				ExtentReportHelpers.logTestAtVerify(error, failureReason, driver);
			}
		}
	}

	/**
	 * The wrapper for AreEqual when case is false. When case is true, verification
	 * will be skipped.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Verify.areEqualWhenCaseIsFalse(switchCondition, 15, actualNumber, _browser.webDriver,
	 * 		"Actual number was not equal to 15 when switch condition was false");
	 * }
	 * </pre>
	 * 
	 * @param switchCondition : The decider whether or not the verification should
	 *                        be done
	 * @param expected        : The expected value
	 * @param actual          : The actual value to be equal to the expected value
	 * @param driver          : The active WebDriver instance
	 * @param failureReason   : The reason to be logged with the failure
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void areEqualWhenCaseIsFalse(Boolean switchCondtion, Object expected, Object actual, WebDriver driver,
			String failureReason) {
		if (!switchCondtion) {
			try {
				Assert.assertEquals(expected, actual, failureReason);
			} catch (AssertionError error) {
				ExtentReportHelpers.logTestAtVerify(error, failureReason, driver);
			}
		}
	}

	/**
	 * The wrapper for AreEqual.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Verify.areEqual(15, actualNumber, _browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param expected : The expected value
	 * @param actual   : The actual value to be equal to the expected value
	 * @param driver   : The active WebDriver instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void areEqual(Object expected, Object actual, WebDriver driver) {
		try {
			Assert.assertEquals(expected, actual);
		} catch (AssertionError error) {
			;
			ExtentReportHelpers.logTestAtVerify(error,
					"Expected : " + expected.toString() + " but was : " + actual.toString(), driver);
		}
	}

	/**
	 * The wrapper for AreNotEqual.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Verify.areNotEqual(15, actualNumber, _browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param expected : The expected value
	 * @param actual   : The actual value to be not equal to the expected value
	 * @param driver   : The active WebDriver instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void areNotEqual(Object expected, Object actual, WebDriver driver) {
		try {
			Assert.assertNotEquals(expected, actual);
		} catch (AssertionError error) {
			ExtentReportHelpers.logTestAtVerify(error,
					"Expected : " + expected.toString() + " and actual : " + actual.toString() + " was equal", driver);
		}
	}

	/**
	 * The wrapper for Is True.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Verify.isTrue(condition, _browser.webDriver, "The condition was false");
	 * }
	 * </pre>
	 * 
	 * @param expected : The expected condition to be true
	 * @param driver   : The active WebDriver Instance
	 * @param message  : The message to be logged with the failure
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void isTrue(Boolean expected, WebDriver driver, String message) {
		try {
			Assert.assertTrue(expected, message);
		} catch (AssertionError error) {
			ExtentReportHelpers.logTestAtVerify(error, message, driver);
		}
	}

	/**
	 * The wrapper for IsFalse.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Verify.isFalse(condition, _browser.webDriver, "The condition was true");
	 * }
	 * </pre>
	 * 
	 * @param expected : The expected condition to be false
	 * @param driver   : The active WebDriver Instance
	 * @param message  : The message to be logged with the failure
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void isFalse(Boolean expected, WebDriver driver, String message) {
		try {
			Assert.assertFalse(expected, message);
		} catch (AssertionError error) {
			ExtentReportHelpers.logTestAtVerify(error, message, driver);
		}
	}

	/**
	 * The wrapper for IsContains.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Verify.isContains(fullNameString, firstNameString, _browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param actualString        : The actual string
	 * @param stringToBeContained : The string to be contained in the actual string
	 * @param driver              : The active WebDriver instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void isContains(String actualString, String stringToBeContained, WebDriver driver) {
		try {
			Assert.assertTrue(actualString.contains(stringToBeContained),
					"'" + actualString + "' does not contains '" + stringToBeContained + "'");
		} catch (AssertionError error) {
			ExtentReportHelpers.logTestAtVerify(error,
					"'" + actualString + "' does not contains '" + stringToBeContained + "'", driver);
		}
	}

	/**
	 * The wrapper for IsNotContains.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Verify.isNotContains(fullNameString, salutationString, _browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param actualString        : The actual string
	 * @param stringToBeContained : The string to be not contained in the actual
	 *                            string
	 * @param driver              : The active WebDriver instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void isNotContains(String actualString, String stringToBeContained, WebDriver driver) {
		try {
			Assert.assertTrue(!actualString.contains(stringToBeContained),
					"'" + actualString + "' does contains '" + stringToBeContained + "'");
		} catch (AssertionError error) {
			ExtentReportHelpers.logTestAtVerify(error,
					"'" + actualString + "' does contains '" + stringToBeContained + "'", driver);
		}
	}

	/**
	 * The wrapper for ListContainsExpectedValue.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Verify.listContainsExpectedValue(listOfEmployeeNames, employeeOneName, _browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param listOfItems  : The list containing string items
	 * @param expecteditem : The expected item to be present in the given list
	 * @param driver       : The active WebDriver instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static <T> void listContainsExpectedValue(List<T> listOfItems, T expecteditem, WebDriver driver) {
		try {
			Boolean flag = false;
			flag = listOfItems.contains(expecteditem);
			Assert.assertTrue(flag, "Expected string '" + expecteditem + "' does not contains in the list of string");
		} catch (AssertionError error) {
			ExtentReportHelpers.logTestAtVerify(error,
					"Expected string '" + expecteditem + "' does not contains in the list of string", driver);
		}
	}

	/**
	 * The wrapper for ListNotContainsExpectedValue.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Verify.listNotContainsExpectedValue(listOfEmployeeNames, jobTitleAsQa, _browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param listOfItems    : The list containing string items
	 * @param expectedString : The expected item to be not present in the given list
	 * @param driver         : The active WebDriver instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static <T> void listNotContainsExpectedValue(List<T> listOfItems, T expecteditem, WebDriver driver) {
		try {
			Boolean flag = false;
			flag = listOfItems.contains(expecteditem);
			Assert.assertFalse(flag, "Expected string '" + expecteditem + "' is present in the list of string");
		} catch (AssertionError error) {
			ExtentReportHelpers.logTestAtVerify(error,
					"Expected string '" + expecteditem + "' is present in the list of string", driver);
		}
	}

	/**
	 * The wrapper for IsStringContainsListOfItems.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Verify.isStringContainsListOfItems(availableJobs, jobTitleList, _browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param actualString : The actual string
	 * @param listOfItems  : The list of items which needs to be present in the
	 *                     actual string
	 * @param driver       : The active WebDriver instance
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void isStringContainsListOfItems(String actualString, List<String> listOfItems, WebDriver driver) {
		for (String item : listOfItems) {
			isContains(actualString, item, driver);
		}
	}

	/**
	 * Verify the two list values are equal.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Verify.actualAndExpectedListItemsAreEqual(availableJobsList, jobTitleList, _browser.webDriver);
	 * }
	 * </pre>
	 * 
	 * @param actualListOfItems   : The actual list of items
	 * @param expectedListOfItems : The expected list to be equal to the actual list
	 * @param driver
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static <T> void actualAndExpectedListItemsAreEqual(List<T> actualListOfItems, List<T> expectedListOfItems,
			WebDriver driver) {
		try {
			Assert.assertEquals(actualListOfItems, expectedListOfItems);
		} catch (AssertionError error) {
			ExtentReportHelpers.logTestAtVerify(error, "Expected list of items are not equal to actual list of items",
					driver);
		}
	}
}