package pace.testautomation.uicore.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Extent report annotation interface.
 * 
 * <pre>
 * How to use :
 * {@code
 * Step 1: Add ExtentReportListener to the TestClass
 * Step 2: Add @ExtentReport annotation to the TestClass
 * }
 * </pre>
 * 
 * @author PACE Team
 * @version 1.0.0
 * @since 2023-03-01
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface ExtentReport {

}
