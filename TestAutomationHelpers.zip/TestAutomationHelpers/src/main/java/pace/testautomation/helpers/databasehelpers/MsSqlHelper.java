package pace.testautomation.helpers.databasehelpers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import pace.testautomation.helpers.utilities.FrameworkHelpersSupport;

public class MsSqlHelper {

	/**
	 * SQL connection object
	 */
	private Connection connection = null;

	/**
	 * SQL connection string
	 */
	private String connectionString;

	/**
	 * Constructor for the 'MsSqlHelper' class
	 * 
	 * @param connectionString : Connection string for the required database
	 * 
	 * @throws SQLException
	 */
	public MsSqlHelper(String connectionString) throws SQLException {
		FrameworkHelpersSupport.FrameworkExpiryDateCheckWithoutWarning();
		this.connectionString = "jdbc:sqlserver://" + connectionString;
	}

	/**
	 * Execute query for retrieving a single value result
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * String result = msSqlDatabase.executeQueryForValue(query1);
	 * 
	 * Boolean condition = msSqlDatabase.<Boolean>executeQueryForValue(query);
	 * }
	 * </pre>
	 * 
	 * @param query : Select query for retrieving the result
	 * 
	 * @return Query result value
	 * 
	 * @author PACE Team
	 * @version 2.2.0
	 * @since 2024-07-01
	 */
	@SuppressWarnings("unchecked")
	public <T> T executeQueryForValue(String query) throws SQLException {
		this.connect();
		Object resultValue = null;
		try (PreparedStatement statement = connection.prepareStatement(query);
				ResultSet resultSet = statement.executeQuery()) {
			if (resultSet.next()) {
				resultValue = resultSet.getObject(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return (T) resultValue;
	}

	/**
	 * Execute query for retrieving a row as result. The column name will be the key
	 * and row value will be the value of the resultant linked hash map.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * LinkedHashMap<String, Object> rowResult = msSqlDatabase.executeQueryForRow(query);
	 * }
	 * </pre>
	 * 
	 * @param query : Select query for retrieving the result
	 * 
	 * @return Query result row
	 * 
	 * @author PACE Team
	 * @version 2.2.0
	 * @since 2024-07-01
	 */
	public LinkedHashMap<String, Object> executeQueryForRow(String query) throws SQLException {
		this.connect();
		LinkedHashMap<String, Object> resultRow = null;
		try (PreparedStatement statement = connection.prepareStatement(query);
				ResultSet resultSet = statement.executeQuery()) {
			resultSet.next();
			resultRow = resultSetToMap(resultSet);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultRow;
	}

	/**
	 * Execute query for retrieving a specific column result
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * List<String> coloumResult = msSqlDatabase.executeQueryForColumn(query);
	 * }
	 * </pre>
	 * 
	 * @param query : Select query for retrieving the result
	 * 
	 * @return Query result column
	 * 
	 * @author PACE Team
	 * @version 2.2.0
	 * @since 2024-07-01
	 */
	@SuppressWarnings("unchecked")
	public <T> List<T> executeQueryForColumn(String query) throws SQLException {
		this.connect();
		List<T> resultColumn = new ArrayList<>();
		try (PreparedStatement statement = connection.prepareStatement(query);
				ResultSet resultSet = statement.executeQuery()) {
			while (resultSet.next()) {
				resultColumn.add((T) resultSet.getObject(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultColumn;
	}

	/**
	 * Execute query for retrieving all the contents of a table. The table will be
	 * placed as a list of multiple linked hash maps each representing a row in the
	 * table.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * List<LinkedHashMap<String, Object>> tableResult = msSqlDatabase.executeQueryForTable(query);
	 * }
	 * </pre>
	 * 
	 * @param query : Select query for retrieving the result
	 * 
	 * @return Query result table
	 * 
	 * @author PACE Team
	 * @version 2.2.0
	 * @since 2024-07-01
	 */
	public List<LinkedHashMap<String, Object>> executeQueryForTable(String query) throws SQLException {
		this.connect();
		List<LinkedHashMap<String, Object>> resultTable = new ArrayList<LinkedHashMap<String, Object>>();
		try (PreparedStatement statement = connection.prepareStatement(query);
				ResultSet resultSet = statement.executeQuery()) {
			while (resultSet.next()) {
				resultTable.add(resultSetToMap(resultSet));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultTable;
	}

	/**
	 * Execute update query for updating the required table.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * msSqlDatabase.executeUpdateQuery(query);
	 * }
	 * </pre>
	 * 
	 * @param query : Update query for updating the table
	 * 
	 * @return The number of rows updated
	 * 
	 * @author PACE Team
	 * @version 2.3.0
	 * @since 2024-07-01
	 */
	public int executeUpdateQuery(String query) throws SQLException {
	    this.connect();
	    int affectedRows = 0;
	    try (PreparedStatement statement = connection.prepareStatement(query)) {
	        affectedRows = statement.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	        throw e; 
	    }
	    return affectedRows;
	}
	
	/**
	 * Disconnect the database
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * msSqlDatabase.disconnect();
	 * }
	 * </pre>
	 *  
	 * @author PACE Team
	 * @version 2.2.0
	 * @since 2024-07-01
	 */
	public void disconnect() throws SQLException {
		if (connection != null && !connection.isClosed()) {
			connection.close();
		}
	}

	/**
	 * Connect to the database if connection was not established earlier or it was closed.
	 *   
	 * @author PACE Team
	 * @version 2.2.0
	 * @since 2024-07-01
	 */
	private void connect() throws SQLException {
		if (this.connection == null || connection.isClosed()) {
			this.connection = DriverManager.getConnection(this.connectionString);
		}
	}

	/**
	 * Convert the result set into a linked hash map of <string, object>
	 * 
	 * @author PACE Team
	 * @version 2.2.0
	 * @since 2024-07-01
	 */
	private LinkedHashMap<String, Object> resultSetToMap(ResultSet resultSet) throws SQLException {
		ResultSetMetaData metaData = resultSet.getMetaData();
		int columnCount = metaData.getColumnCount();
		LinkedHashMap<String, Object> resultMap = new LinkedHashMap<String, Object>();
		for (int i = 1; i <= columnCount; i++) {
			String columnName = metaData.getColumnName(i);
			Object columnValue = resultSet.getObject(i);
			resultMap.put(columnName, columnValue);
		}
		return resultMap;
	}
}