package pace.testautomation.helpers.statichelpers;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.json.JSONObject;

import pace.testautomation.helpers.utilities.FrameworkHelpersSupport;
public class JsonHelpers {

	static {
		FrameworkHelpersSupport.FrameworkExpiryDateCheckWithoutWarning();
	}
	
	/**
	 * Load test data from the 'test-data' folder kept in src/test/resources
	 * 
	 * <pre>
	 * How to use :
	 * {@code
     * JSONObject testData = JsonHelpers.loadTestData("testDataFolderName", "testDataFileName");
	 * }
	 * </pre>
	 * 
	 * @param testDataFolder : Name of the folder kept inside 'test-data' folder
	 * @param testDataFileName : Test-data file name.
	 * 
	 * @return Test data
	 * 
	 * @throws FileNotFoundException
	 * @throws IOException
	 * 
	 * @author PACE Team
	 * @version 2.1.0
	 * @since 2024-07-01
	 */
	public static JSONObject loadTestData(String testDataFolder, String testDataFileName)
			throws FileNotFoundException, IOException {
		 String jsonString = new String(Files.readAllBytes(Paths.get(System.getProperty("user.dir")
					+ "\\src\\test\\resources\\test-data\\" + testDataFolder + "\\" + testDataFileName + ".json")));
		 JSONObject jsonObject = new JSONObject(jsonString);
		return jsonObject;
	}
	
	/**
	 * Load payloads from the 'payloads' folder kept in src/test/resources
	 * 
	 * <pre>
	 * How to use :
	 * {@code
     * JSONObject payloads = JsonHelpers.loadPayloads("payloadFolderName", "payloadFileName");
	 * }
	 * </pre>
	 * 
	 * @param payloadFolderName : Name of the folder kept inside 'payloads' folder
	 * @param payloadFileName : Payloads file name.
	 * 
	 * @return Payloads as JSON object
	 * 
	 * @throws FileNotFoundException
	 * @throws IOException
	 * 
	 * @author PACE Team
	 * @version 2.4.0
	 * @since 2024-07-15
	 */
	public static JSONObject loadPayloads(String payloadFolderName, String payloadFileName)
			throws FileNotFoundException, IOException {
		 String jsonString = new String(Files.readAllBytes(Paths.get(System.getProperty("user.dir")
					+ "\\src\\test\\resources\\payloads\\" + payloadFolderName + "\\" + payloadFileName + ".json")));
		 JSONObject jsonObject = new JSONObject(jsonString);
		return jsonObject;
	}
	
	/**
	 * Load environment variables from the 'environment-variables' folder kept in src/main/resources
	 * The environment file name is taken from the 'System.getProperty("environment")'
	 * 
	 * <pre>
	 * How to use :
	 * {@code
     * JSONObject envVariables = JsonHelpers.loadEnvironmentVariables();
	 * }
	 * </pre>
	 * 
	 * @return Environment variables
	 * 
	 * @throws FileNotFoundException
	 * @throws IOException
	 * 
	 * @author PACE Team
	 * @version 2.1.0
	 * @since 2024-07-01
	 */
	public static JSONObject loadEnvironmentVariables()
			throws FileNotFoundException, IOException {
		 String jsonString = new String(Files.readAllBytes(Paths.get(System.getProperty("user.dir")
					+ "\\src\\main\\resources\\environment-variables\\" + System.getProperty("environment") + ".json")));
		 JSONObject jsonObject = new JSONObject(jsonString);
		return jsonObject;
	}
	
	/**
	 * Read test data from the 'TestData' folder kept in src/test/java
	 * 
	 * <pre>
	 * How to use :
	 * {@code
     * JSONObject testData = JsonHelpers.readTestData("testDataFolderName", "testDataFileName");
	 * }
	 * </pre>
	 * 
	 * @param testDataFolder : Name of the folder kept inside 'TestData' folder
	 * @param testDataFileName : Test-data file name.
	 * 
	 * @return Test data
	 * 
	 * @throws FileNotFoundException
	 * @throws IOException
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static JSONObject readTestData(String testDataFolder, String testDataFileName)
			throws FileNotFoundException, IOException {
		 String jsonString = new String(Files.readAllBytes(Paths.get(System.getProperty("user.dir")
					+ "\\src\\test\\java\\TestData\\" + testDataFolder + "\\" + testDataFileName + ".json")));
		 JSONObject jsonObject = new JSONObject(jsonString);
		return jsonObject;
	}

	/**
	 * Read json data from the file path
	 * 
	 * <pre>
	 * How to use :
	 * {@code
     * JSONObject testData = JsonHelpers.readJsonData("/jsonDataFilePath");
	 * }
	 * </pre>
	 * 
	 * @param jsonDataFilePath
	 * @return Json data
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws ParseException
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static JSONObject readJsonData(String jsonDataFilePath)
			throws FileNotFoundException, IOException {
		 String jsonString = new String(Files.readAllBytes(Paths.get(System.getProperty("user.dir")
					+ jsonDataFilePath)));
		 JSONObject jsonObject = new JSONObject(jsonString);
		return jsonObject;
	}
}