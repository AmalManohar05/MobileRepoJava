package pace.testautomation.helpers.statichelpers;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import org.jasypt.util.text.AES256TextEncryptor;

import pace.testautomation.helpers.utilities.FrameworkHelpersSupport;

public class StringHelpers {

	static {
		FrameworkHelpersSupport.FrameworkExpiryDateCheckWithoutWarning();
	}
	
	/**
	 * Url decode
	 * 
	 * <pre>
	 * How to use :
	 * {@code
     * string decodedUrl = StringHelpers.urlDecode("encodedUrl");
	 * }
	 * </pre>
	 * 
	 * @param url
	 * @return decoded url
	 * @throws UnsupportedEncodingException
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static String urlDecode(String url) throws UnsupportedEncodingException {
		return java.net.URLDecoder.decode(url, StandardCharsets.UTF_8.name());
	}

	/**
	 * Url encode
	 * 
	 * <pre>
	 * How to use :
	 * {@code
     * string encodedUrl = StringHelpers.urlEncode("decodedUrl");
	 * }
	 * </pre>
	 * 
	 * @param url
	 * @return encoded url
	 * @throws UnsupportedEncodingException
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static String urlEncode(String url) throws UnsupportedEncodingException {
		return URLEncoder.encode(url, StandardCharsets.UTF_8);
	}

	/**
	 * Decrypting the password
	 * 
	 * <pre>
	 * How to use :
	 * {@code
     * string decryptedPassword = StringHelpers.decryptPassword("passwordFromConfigFile");
	 * }
	 * </pre>
	 * 
	 * @param passwordFromConfigFile
	 * @return decrypted password
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public String decryptPassword(String passwordFromConfigFile) {
		AES256TextEncryptor aesEncryptor = new AES256TextEncryptor();
		aesEncryptor.setPassword(passwordFromConfigFile);
		String decryptedPassword = aesEncryptor.decrypt(passwordFromConfigFile);
		return decryptedPassword;
	}
}