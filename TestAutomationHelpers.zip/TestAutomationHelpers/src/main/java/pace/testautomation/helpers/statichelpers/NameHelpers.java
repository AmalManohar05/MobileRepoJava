package pace.testautomation.helpers.statichelpers;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import pace.testautomation.helpers.utilities.FrameworkHelpersSupport;

public class NameHelpers {

	static {
		FrameworkHelpersSupport.FrameworkExpiryDateCheckWithoutWarning();
	}
	
	/**
	 * Random name generator
	 * 
	 * <pre>
	 * How to use :
	 * {@code
     * string randomName = NameHelpers.randomWordGenerator();
	 * }
	 * </pre>
	 * 
	 * @return Random name
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static String randomWordGenerator() {
		final String lexicon = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		final java.util.Random rand = new java.util.Random();
		final Set<String> identifiers = new HashSet<String>();
		StringBuilder builder = new StringBuilder();
		while (builder.toString().length() == 0) {
			int length = rand.nextInt(5) + 5;
			for (int i = 0; i < length; i++) {
				builder.append(lexicon.charAt(rand.nextInt(lexicon.length())));
			}
			if (identifiers.contains(builder.toString())) {
				builder = new StringBuilder();
			}
		}
		return builder.toString();
	}

	/**
	 * Random name and number generator
	 * 
	 * <pre>
	 * How to use :
	 * {@code
     * string randomName = NameHelpers.randomWordAndNumberGenerator();
	 * }
	 * </pre>
	 * 
	 * @param desiredLength
	 * @return Random names and number with given length
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static String randomWordAndNumberGenerator() {
		final String lexicon = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		final java.util.Random rand = new java.util.Random();
		final Set<String> identifiers = new HashSet<String>();
		StringBuilder builder = new StringBuilder();
		while (builder.toString().length() == 0) {
			int length = rand.nextInt(5) + 5;
			for (int i = 0; i < length; i++) {
				builder.append(lexicon.charAt(rand.nextInt(lexicon.length())));
			}
			if (identifiers.contains(builder.toString())) {
				builder = new StringBuilder();
			}
		}
		return builder.toString();
	}
	
	/**
	 * Random UUID generator
	 * 
	 * <pre>
	 * How to use :
	 * {@code
     * string randomUUID = NameHelpers.randomUUIDGenerator();
	 * }
	 * </pre>
	 * 
	 * @return Random names and number with given length
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static String randomUUIDGenerator() {
		String random = UUID.randomUUID().toString();
		return random;
	}
}