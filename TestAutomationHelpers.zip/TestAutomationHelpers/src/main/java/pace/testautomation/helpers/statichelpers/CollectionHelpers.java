package pace.testautomation.helpers.statichelpers;

import java.util.Collection;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import pace.testautomation.helpers.utilities.FrameworkHelpersSupport;

import java.util.function.Consumer;
import java.util.function.Function;

public class CollectionHelpers {
	
	static {
		FrameworkHelpersSupport.FrameworkExpiryDateCheckWithoutWarning();
	}

    /**
     * Checks whether the given item is unique within the collection
     * 
     * <pre>
	 * How to use :
	 * {@code
	 * boolean isItemUnique = CollectionHelpers.isUnique(collectionList, item);
	 * }
	 * </pre>
	 * 
     * @param collection
     * @param item
     * @return True if the given value is unique, else false
     * 
     * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
     */
    public static <T> boolean isUnique(Collection<T> collection, T item) {
        return collection.stream().filter(x -> x.equals(item)).count() == 1;
    }

    /**
     *  Checks whether the given condition is unique within the collection.
     *  
     * <pre>
	 * How to use :
	 * {@code
	 * boolean isItemUnique = CollectionHelpers.isUnique(collectionList, item -> item == 1);
	 * }
	 * </pre>
	 * 
     * @param collection
     * @param condition
     * @return True if the given value is unique which meets a particular condition, else false
     * 
     * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
     */
    public static <T> boolean isUnique(Collection<T> collection, Predicate<T> condition) {
        return collection.stream().filter(condition).count() == 1;
    }

    /**
     *  Checks whether the given collection is distinct.
     *  
     * <pre>
	 * How to use :
	 * {@code
	 * boolean isTheValueDistinct = CollectionHelpers.isDistinct(collectionList);
	 * }
	 * </pre>
	 * 
     * @param collection
     * @return True if the collection is distinct, otherwise false.
     * 
     * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
     */
    public static <T> boolean isDistinct(Collection<T> collection) {
        return collection.stream().allMatch(x -> isUnique(collection, x));
    }

    /**
     *  Performs an action for all the items in a collection
     *  
     * <pre>
	 * How to use :
	 * {@code
	 * CollectionHelpers.forAll(collectionList, x-> Verify.isTrue( x > 15));
	 * }
	 * </pre>
	 * 
     * @param collection
     * @param action
     * 
     * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
     */
    public static <T> void forAll(Collection<T> collection, Consumer<T> action) {
        collection.forEach(action);
    }

    /**
     *  Checks whether the given child collection is present in the parent collection.
     *  
     * <pre>
	 * How to use :
	 * {@code
	 * bool isValueContainsTheList = CollectionHelpers.containsTheList(parentList, childList);
	 * }
	 * </pre>
	 * 
     * @param <T>
     * @param parent
     * @param child
     * @return True if the child list was present in parent list, otherwise false
     * 
     * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
     */
    public static <T> boolean containsTheList(Collection<T> parent, Collection<T> child) {
        return child.stream().allMatch(x -> parent.contains(x));
    }
    
    /**
     *  Transforms the given collection into a new collection.
     *  
     * <pre>
	 * How to use :
	 * {@code
	 * List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
	 * Function<Integer, String> toStringAction = Object::toString;
	 * List<Integer> transformedList = CollectionHelpers.transform(numbers, toStringAction);
	 * }
	 * </pre>
	 * 
     * @param collection
     * @param action
     * @return Tranformed list after performing particular action
     * 
     * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
     */
    public static <T, R> List<R> transform(Collection<T> collection, Function<T,R> action)
    {
    	return collection.stream().map(action).collect(Collectors.toList());
    }
    
    /**
     *  Filters the given collection based on given condition.
     *  
     * <pre>
	 * How to use :
	 * {@code
	 * List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
	 * List<Integer> filteredList = CollectionHelpers.filter(numbers, num -> num % 2 == 0);
	 * }
	 * </pre>
	 * 
     * @param collection
     * @param action
     * @return Filtered list with given condition
     * 
     * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
     */
    public static <T> List<T> filter( Collection<T> collection, Predicate<T> condition)
    {
    	return collection.stream().filter(condition).collect(Collectors.toList());
    }
}