package pace.testautomation.helpers.statichelpers;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvException;

import pace.testautomation.helpers.utilities.FrameworkHelpersSupport;

public class ExcelHelpers {

	static {
		FrameworkHelpersSupport.FrameworkExpiryDateCheckWithoutWarning();
	}
	
	/**
	 * Load csv file into List
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * List<string> fileDetails = ExcelHelpers.loadCsvFile("/filePath");
	 * }
	 * </pre>
	 * 
	 * @param filePath
	 * @return CSV file as list<string>
	 * @throws IOException
	 * @throws CsvException
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static List<String[]> loadCsvFile(String filePath) throws IOException, CsvException {
		CSVReader csvReader = new CSVReaderBuilder(
				new FileReader(System.getProperty("user.dir") + File.separator + filePath)).build();
		List<String[]> allData = csvReader.readAll();
		return allData;
	}

}