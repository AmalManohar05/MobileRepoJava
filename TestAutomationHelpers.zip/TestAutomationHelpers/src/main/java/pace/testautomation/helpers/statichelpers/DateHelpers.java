package pace.testautomation.helpers.statichelpers;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

import pace.testautomation.helpers.utilities.FrameworkHelpersSupport;

public class DateHelpers {

	static {
		FrameworkHelpersSupport.FrameworkExpiryDateCheckWithoutWarning();
	}
	
	/**
	 * Calendar object
	 */
	private static Calendar calendar;

	/**
	 * Invoke constructor to initialize the object
	 */
	private DateHelpers() {
		calendar = Calendar.getInstance();
	}

	/**
	 * Get date with specific format
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * string dateWithSpecificFormat = DateHelpers.getDateWithSpecificFormat("dd-MM-yyyy");
	 * }
	 * </pre>
	 * 
	 * @param specificFormat
	 * @return date with specific fromat
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static String getDateWithSpecificFormat(String specificFormat) {
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern(specificFormat);
		LocalDateTime now = LocalDateTime.now();
		return dateFormat.format(now).toString();
	}

	/**
	 * Gets the future or past date with specific format and adding no of days.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * string futureDateWithSpecificFormat = DateHelpers.getFutureOrPastDate("dd-MM-yyyy", 5);
	 * }
	 * </pre>
	 * 
	 * @param specificFormat
	 * @param noOfDays
	 * @return future or past date
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static String getFutureOrPastDate(String specificFormat, int noOfDays) {
		calendar.add(Calendar.DATE, noOfDays);
		return new SimpleDateFormat(specificFormat).format(calendar.getTime()).toString();
	}

	/**
	 * Get the current month
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * int currentMonth = DateHelpers.getCurrentMonth();
	 * }
	 * </pre>
	 * 
	 * @return current month
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static int getCurrentMonth() {
		return calendar.get(Calendar.MONTH);
	}

	/**
	 * Get the current day of week
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * int currentDay = DateHelpers.getCurrentDay();
	 * }
	 * </pre>
	 *
	 * @return current day
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static int getCurrentDay() {
		return calendar.get(Calendar.DAY_OF_WEEK);
	}

	/**
	 * Get the current year
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * int currentYear = DateHelpers.getCurrentYear();
	 * }
	 * </pre>
	 * 
	 * @return current year
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static int getCurrentYear() {
		return calendar.get(Calendar.YEAR);
	}

}