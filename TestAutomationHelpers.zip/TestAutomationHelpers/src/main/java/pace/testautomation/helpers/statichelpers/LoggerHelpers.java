package pace.testautomation.helpers.statichelpers;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import pace.testautomation.helpers.utilities.FrameworkHelpersSupport;

public class LoggerHelpers {
	
	static {
		FrameworkHelpersSupport.FrameworkExpiryDateCheckWithoutWarning();
	}
	
	/**
	 * To set the log file
	 * 
	 * <pre>
	 * How to use :
	 * {@code
     * LoggerHelpers.logger.info("Your information message here");
	 * }
	 * </pre>
	 * 
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static Logger logger = LogManager.getLogger(LoggerHelpers.class);
}