package pace.testautomation.helpers.statichelpers;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.List;

import pace.testautomation.helpers.utilities.FrameworkHelpersSupport;

public class RobotHelpers {

	 private static Robot robot;

	    static {	    	
	    	FrameworkHelpersSupport.FrameworkExpiryDateCheckWithoutWarning();
	        try {
	            robot = new Robot();
	        } catch (Exception exp) {
	            exp.printStackTrace();
	        }
	    }
	    
	/**
	 * This method will set the string to the system's clipboard.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
     * RobotHelpers.setClipboardData("stringValue");
	 * }
	 * </pre>
	 * 
	 * @param string
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	private static void setClipboardData(String string) {
		StringSelection stringSelection = new StringSelection(string);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
	}

	/**
	 * This method will upload the file from the give location.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
     * RobotHelpers.uploadFile("/filePath");
	 * }
	 * </pre>
	 * 
	 * @param fileLocation
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void uploadFile(String fileLocation) {
		try {
			setClipboardData(fileLocation);
			Thread.sleep(2000);
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			Thread.sleep(2000);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(2000);
		} 
		catch (Exception exp) {
			exp.printStackTrace();
		}
	}
	
	/**
	 * This method will close the active popup window
	 * 
	 * <pre>
	 * How to use :
	 * {@code
     * RobotHelpers.closeActivePopupWindow();
	 * }
	 * </pre>
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void closeActivePopupWindow() {
		try {
            robot.keyPress(KeyEvent.VK_ALT);
            robot.keyPress(KeyEvent.VK_F4);
            robot.keyRelease(KeyEvent.VK_F4);
            robot.keyRelease(KeyEvent.VK_ALT);
            Thread.sleep(1000);
		} 
		catch (Exception exp) {
			exp.printStackTrace();
		}
	}
	
	/**
	 * This method will type the given text content to the selected field.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
     * RobotHelpers.typeTextContent("textContent");
	 * }
	 * </pre>
	 * 
	 * @param textContent
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void typeTextContent(String textContent) {
		try {
			setClipboardData(textContent);
			Thread.sleep(2000);
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			Thread.sleep(2000);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(2000);
		} 
		catch (Exception exp) {
			exp.printStackTrace();
		}
	}
	
	/**
	 * This method will press and release the given keyboard key.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * int keyEvent = KeyEvent.VK_ENTER;
     * RobotHelpers.pressSingleKey(keyEvent);
	 * }
	 * </pre>
	 * 
	 * @param textContent
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void pressSingleKey(int keyEvent) {
		try {
			Thread.sleep(1000);
			robot.keyPress(keyEvent);
			robot.keyRelease(keyEvent);
			Thread.sleep(1000);
		} 
		catch (Exception exp) {
			exp.printStackTrace();
		}
	}
	
	/**
	 * This method will press the given series of key and release them.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * List<Integer> keyEvents = new ArrayList<>();
	 * keyEvents.add(KeyEvent.VK_CONTROL);
     * keyEvents.add(KeyEvent.VK_SHIFT);
     * keyEvents.add(KeyEvent.VK_F);
     * RobotHelpers.pressSeriesOfKeys(keyEvents);
	 * }
	 * </pre>
	 * 
	 * @param textContent
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void pressSeriesOfKeys(List<Integer> keyEvents) {
		try {
			Thread.sleep(1000);
			keyEvents.forEach(key ->
			{
				robot.keyPress(key);
			}
			);
			keyEvents.forEach(key ->
			{
				robot.keyRelease(key);
			}
			);
			Thread.sleep(1000);
		} 
		catch (Exception exp) {
			exp.printStackTrace();
		}
	}
}