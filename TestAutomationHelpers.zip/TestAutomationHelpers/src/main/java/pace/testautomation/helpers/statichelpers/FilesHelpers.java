package pace.testautomation.helpers.statichelpers;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

import pace.testautomation.helpers.utilities.FrameworkHelpersSupport;

public class FilesHelpers {
	
	static {
		FrameworkHelpersSupport.FrameworkExpiryDateCheckWithoutWarning();
	}

	/**
	 * Get content of a pdf file.
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * string pdfContent = FilesHelpers.getPdfFileContent("/filePath");
	 * }
	 * </pre>
	 * 
	 * @param filePath
	 * @return Pdf file content
	 * @throws IOException
	 */
	public static String getPdfFileContent(String filePath) throws IOException {
		String text = null;
		PDDocument document = Loader.loadPDF(new File(filePath));
		if (!document.isEncrypted()) {
			PDFTextStripper stripper = new PDFTextStripper();
			text = stripper.getText(document);
			System.out.println("Text:" + text);
		}
		return text.toString();
	}

	/**
	 * Delete all the files and sub folder from allure results
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * FilesHelpers.deleteAllTheFilesAndSubFolderFromAllureResults();
	 * }
	 * </pre>
	 * 
	 * @throws IOException
	 */
	public static void deleteAllTheFilesAndSubFolderFromAllureResults() throws IOException {
		File directory = new File(System.getProperty("user.dir") + File.separator + "allure-results");
		FileUtils.cleanDirectory(directory);
	}

	/**
	 * Rename the file
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * FilesHelpers.renameTheFile("/filePath", "newFileName");
	 * }
	 * </pre>
	 * 
	 * @param filePath
	 * @param newFileName
	 */
	public static void renameTheFile(String filePath, String newFileName) {
		Path source = Paths.get(System.getProperty("user.dir") + File.separator + filePath);
		try {
			Files.move(source, source.resolveSibling(newFileName));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create a folder
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * FilesHelpers.createFolder("/folderPath");
	 * }
	 * </pre>
	 * 
	 * @param path
	 */
	public static void createFolder(String path) {
		File theDir = new File(path);
		if (!theDir.exists()) {
			theDir.mkdirs();
		}
	}

	/**
	 * Get file content
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * string fileContent = FilesHelpers.getFileContent("/filePath");
	 * }
	 * </pre>
	 * 
	 * @param filePath
	 * @return file content
	 * @throws IOException
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static String getFileContent(String filePath) throws IOException {
		return Files.readString(Paths.get(filePath)).toString();
	}

	/**
	 * Delete the file
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * FilesHelpers.deleteFile("/filePath");
	 * }
	 * </pre>
	 * 
	 * @param filePath
	 * @throws IOException
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void deleteFile(String filePath) throws IOException {
		File file = new File(System.getProperty("user.dir") + File.separator + filePath);
		file.delete();
	}

	/**
	 * Delete folder
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * FilesHelpers.deleteFolder("/destination");
	 * }
	 * </pre>
	 * 
	 * @param destination
	 * @throws IOException
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void deleteFolder(String destination) throws IOException {
		FileUtils.deleteDirectory(new File(destination));
	}

	/**
	 * Write the file
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * FilesHelpers.writeFile("/filePath", "fileContent");
	 * }
	 * </pre>
	 * 
	 * @param filePath
	 * @param fileContent
	 * @throws IOException
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void writeFile(String filePath, String fileContent) throws IOException {
		FileWriter fileWriter = new FileWriter(System.getProperty("user.dir") + File.separator + filePath);
		fileWriter.write(fileContent);
		fileWriter.close();
	}

	/**
	 * Copy the file
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * File sourceFile = new File("path/to/source/file.txt");
     * File destinationFile = new File("path/to/destination/file.txt");
     * FilesHelpers.copyFile(sourceFile, destinationFile);
	 * }
	 * </pre>
	 * 
	 * @param source
	 * @param destination
	 * @throws IOException
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void copyFile(File source, File destination) throws IOException {
		FileUtils.copyFile(source, destination);
	}
	
	/**
	 * Get the path of 'Uploads' folder kept inside src/main/java .
	 * 
	 * <pre>
	 * How to use :
	 * {@code
     * string uploadsFolderPath = FilesHelpers.getUploadsFolderPath();
	 * }
	 * </pre>
	 * 
	 * @return Path of upload folder
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static String getUploadsFolderPath() {
		Path currentDirPath = Paths.get(System.getProperty("user.dir"));
        String currentDirString = currentDirPath.toString();
        return currentDirString +  "\\src\\main\\java\\Uploads\\";
	}
	
	/**
	 * Get the path of 'uploads' folder kept inside src/test/resources .
	 * 
	 * <pre>
	 * How to use :
	 * {@code
     * string uploadsFolderPath = FilesHelpers.getTheUploadsFolderPath();
	 * }
	 * </pre>
	 * 
	 * @return Path of upload folder
	 * 
	 * @author PACE Team
	 * @version 2.1.0
	 * @since 2024-07-01
	 */
	public static String getTheUploadsFolderPath() {
		Path currentDirPath = Paths.get(System.getProperty("user.dir"));
        String currentDirString = currentDirPath.toString();
        return currentDirString +  "\\src\\test\\resources\\uploads\\";
	}
}