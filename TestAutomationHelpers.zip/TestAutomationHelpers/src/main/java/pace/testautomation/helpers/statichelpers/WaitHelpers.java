package pace.testautomation.helpers.statichelpers;

import java.util.concurrent.Callable;
import java.util.concurrent.TimeoutException;

import pace.testautomation.helpers.utilities.FrameworkHelpersSupport;

public class WaitHelpers {

	static {
		FrameworkHelpersSupport.FrameworkExpiryDateCheckWithoutWarning();
	}

	/**
	 * Wait helper for a function to achieve the goal until a particular time
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Callable<Boolean> myFunc = () -> {
	 * 	// Your condition checking logic here
	 * 	// For example, return true if the condition is met, false otherwise
	 * 	return someConditionIsMet();
	 * };
	 * WaitHelpers.wait(myFunc, 5000, "Timeout occurred waiting for the condition to be met");
	 * }
	 * </pre>
	 * 
	 * @param myFunc   : The function without an argument which returns a boolean
	 *                 condition
	 * @param waitTime :The total time given for the condition to be achieved
	 * @param message  : The message for the timeout exception
	 * 
	 * @throws TimeoutException
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void wait(Callable<Boolean> myFunc, long waitTime, String message) throws TimeoutException {
		Boolean condition = false;
		long start_time = System.currentTimeMillis();
		long end_time = start_time + waitTime;
		do {
			try {
				condition = myFunc.call();
			} catch (Exception e) {
			}
		} while (!condition && System.currentTimeMillis() < end_time);

		if (condition == false) {
			throw new TimeoutException(message);
		}
	}

	/**
	 * Wait helper for a function to achieve the goal until a particular time
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Callable<Boolean> myFunc = () -> {
	 * 	// Your condition checking logic here
	 * 	// For example, return true if the condition is met, false otherwise
	 * 	return someConditionIsMet();
	 * };
	 * WaitHelpers.wait(myFunc, 60000, 2000, "Timeout occurred waiting for the condition to be met");
	 * }
	 * </pre>
	 * 
	 * @param myFunc        : The function without an argument which returns a
	 *                      boolean condition
	 * @param totalWaitTime :The total time given for the condition to be achieved
	 * @param pauseInterval : The time to be paused between successive condition
	 *                      check
	 * @param message       : The message for the timeout exception
	 * 
	 * @throws TimeoutException
	 * 
	 * @author PACE Team
	 * @version 2.4.0
	 * @since 2023-07-15
	 */
	public static void wait(Callable<Boolean> myFunc, long totalWaitTime, long pauseInterval, String message)
			throws TimeoutException, InterruptedException {
		Boolean condition = false;
		long start_time = System.currentTimeMillis();
		long end_time = start_time + totalWaitTime;
		do {
			try {
				condition = myFunc.call();
			} catch (Exception e) {
			}
			Thread.sleep(pauseInterval);
		} while (!condition && System.currentTimeMillis() < end_time);

		if (condition == false) {
			throw new TimeoutException(message);
		}
	}

	/**
	 * Wait helper for a function to achieve the goal until a particular time. This
	 * method does not throw an exception if the goal is not achieve
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Callable<Boolean> myFunc = () -> {
	 * 	// Your condition checking logic here
	 * 	// For example, return true if the condition is met, false otherwise
	 * 	return someConditionIsMet();
	 * };
	 * WaitHelpers.wait(myFunc, 5000, "Timeout occurred waiting for the condition to be met");
	 * }
	 * </pre>
	 * 
	 * @param myFunc   : The function without an argument which returns a boolean
	 *                 condition
	 * @param waitTime :The total time given for the condition to be achieved
	 * 
	 * @return The condition after given time
	 * 
	 * @author PACE Team
	 * @version 2.4.0
	 * @since 2023-07-15
	 */
	public static Boolean wait(Callable<Boolean> myFunc, long waitTime) {
		Boolean condition = false;
		long start_time = System.currentTimeMillis();
		long end_time = start_time + waitTime;
		do {
			try {
				condition = myFunc.call();
			} catch (Exception e) {
			}
		} while (!condition && System.currentTimeMillis() < end_time);
		return condition;
	}

	/**
	 * Wait helper for a function to achieve the goal until a particular time. This
	 * method does not throw an exception if the goal is not achieve
	 * 
	 * <pre>
	 * How to use :
	 * {@code
	 * Callable<Boolean> myFunc = () -> {
	 * 	// Your condition checking logic here
	 * 	// For example, return true if the condition is met, false otherwise
	 * 	return someConditionIsMet();
	 * };
	 * WaitHelpers.wait(myFunc, 5000, "Timeout occurred waiting for the condition to be met");
	 * }
	 * </pre>
	 * 
	 * @param myFunc        : The function without an argument which returns a
	 *                      boolean condition
	 * @param totalWaitTime :The total time given for the condition to be achieved
	 * @param pauseInterval : The time to be paused between successive condition
	 *                      check
	 * 
	 * @return The condition after given time
	 * 
	 * @throws InterruptedException
	 * 
	 * @author PACE Team
	 * @version 2.4.0
	 * @since 2023-07-15
	 */
	public static Boolean wait(Callable<Boolean> myFunc, long totalWaitTime, long pauseInterval)
			throws InterruptedException {
		Boolean condition = false;
		long start_time = System.currentTimeMillis();
		long end_time = start_time + totalWaitTime;
		do {
			try {
				condition = myFunc.call();
			} catch (Exception e) {
			}
			Thread.sleep(pauseInterval);
		} while (!condition && System.currentTimeMillis() < end_time);
		return condition;
	}
	
	public static long ExtraSmallWait = 500;
	public static long SmallWait = 1000;
	public static long DefaultWait = 2000;
	public static long HardWait = 5000;
	public static long ExtraHardWait = 10000;
	public static long ExceptionalHardWait = 20000;
	public static long DbUpdateWait = 30000;
	public static long ExternalServiceWait = 40000;

	/**
	 * Enumerators for wait types.
	 *
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static enum WaitType {
		ExtraSamllWait, SmallWait, DefaultWait, HardWait, ExtraHardWait, ExceptionalHardWait, DbUpdateWait,
		ExternalServiceWait
	}

	/**
	 * Wait function for thread.sleep() based on wait type enums
	 * 
	 * <pre>
	 * How to use :
	 * {@code
     * WaitHelpers.wait(WaitType.SmallWait);
	 * }
	 * </pre>
	 * 
	 * @param wait
	 * @throws InterruptedException
	 * 
	 * @author PACE Team
	 * @version 1.0.0
	 * @since 2023-03-01
	 */
	public static void wait(Enum<?> wait) throws InterruptedException {
		if (wait.equals(WaitType.ExtraSamllWait)) {
			Thread.sleep(ExtraSmallWait);
		} else if (wait.equals(WaitType.SmallWait)) {
			Thread.sleep(SmallWait);
		} else if (wait.equals(WaitType.DefaultWait)) {
			Thread.sleep(DefaultWait);
		} else if (wait.equals(WaitType.HardWait)) {
			Thread.sleep(HardWait);
		} else if (wait.equals(WaitType.ExtraHardWait)) {
			Thread.sleep(ExtraHardWait);
		} else if (wait.equals(WaitType.ExceptionalHardWait)) {
			Thread.sleep(ExceptionalHardWait);
		} else if (wait.equals(WaitType.DbUpdateWait)) {
			Thread.sleep(DbUpdateWait);
		} else if (wait.equals(WaitType.ExternalServiceWait)) {
			Thread.sleep(ExternalServiceWait);
		}
	}
}